<?php




 print_r(file_get_contents('https://account.auftera.com/account/payment/loc_of_pay.php'));


?>