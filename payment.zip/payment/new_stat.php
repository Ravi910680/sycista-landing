<?php

session_start();

$_SESSION['req_page_of_land']=$_GET['req_frm_url'];





?>