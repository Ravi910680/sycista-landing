<?php

session_start();



require("./confige/confige_pln.php");

$id="123";

$req_pln_data=$_SESSION['store_of_post_data_2'];

if(isset($req_pln_data)){

$str = file_get_contents("../../enterprise/data_of_pln.json");

$arr_of_data=(array)json_decode($str);



$isrt_query_fld="(id";

$isrt_val="('".$id."'";

if(isset($req_pln_data['pln_tms_sel_nm'])){

foreach ($arr_of_data as $key => $value) {
	

$isrt_query_fld.=",".$arr_of_data[$key]->id;

$isrt_val.=",'".$arr_of_data[$key]->value_con*$req_pln_data['pln_tms_sel_nm']."'";


}

}else{


foreach ($arr_of_data as $key => $value) {
	
	
$isrt_query_fld.=",".$arr_of_data[$key]->id;

$isrt_val.=",'".$req_pln_data[$key]."'";

}


}

$isrt_query_fld.=",date_time)";

$isrt_val.=",'".gmdate('Y-m-d H:i:s')."')";


$isrt_query_lst="INSERT INTO pln_data ".$isrt_query_fld." VALUES ".$isrt_val;


if ($conn_of_pln->query($isrt_query_lst) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

unset($_SESSION['store_of_post_data_2']);

}else{


	header("Location: ");
}
?>