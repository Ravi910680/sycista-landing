<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn_of_pln = new mysqli($servername, $username, $password,'plan');

// Check connection
if ($conn_of_pln->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>