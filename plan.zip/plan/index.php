<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>
</head>

<link rel="stylesheet" type="text/css" href="../css/main.css">

<style type="text/css">


body{
    font-family: 'lato' !important;
letter-spacing:0.2px;
}

table{
    font-family: 'lato';
}

a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.c-nav--primary {
    padding: 0;
    height: 10vh;
    background-color: #fff;
    border-bottom: 1px solid #ebeaeb;
    z-index: 1000;
    top: 0;
    position: fixed;

  }
.c-slacklogo{
    width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
    font-weight: 400;
}

.main-conetent{
    margin-top: 10vh;

  }

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}


.row{
    margin: 0px;
}
.rw-mini-con{
    padding: 100px 80px;
}

.col-txt-of-rw{
    padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

    background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }

    .txt_alg_cnt{
        text-align: center;
    }


    .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

    .col_height_300{
        min-height: 350px;
    }








    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
}




.rw-mini-con {
    padding: 100px 80px;
   
    overflow: scroll;
  }
  

  .div-dsgn {
    text-align: center;
    margin: 20px 0px;
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1612195541/landing/Horiz-line_tgfmhw.jpg);
    background-size: contain;
  }
  .div-txt-con.c-billboard__kicker.c-billboard__kicker__text.u-text--uppercase {
    text-align: center;
    color: white;
    background: #4a154b;
    padding: 10px;
    border-radius: 1000px;
  }


  li.fet-btn-li {
    list-style: none;
    padding: 10px;
    font-size: 15px;
    font-weight: 600;
    font-family: 'Lato', sans-serif;
    border: 2px solid #611f69;
    border-radius: 10px;
    margin-top: 10px;
  }

  ul.ul-lst-of-fet {
    width: 300px;
    border-radius: 10px;
    
  }

  .fet-btn-li-act{
    background: #611f69;
    color: white;
  }

  .main-mac-scr {
    border-radius: 10px;
    background: #2b092b;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
    border-right: none !important;
  }
  .rw-mini-con {
    padding: 80px 0px;
    overflow: scroll;
  }
  
  li.li-fr-side-nav {
    list-style: none;
    padding: 10px;
  }
  .main-bod-con {
    width: 88%;
    height: 300px;
    background: white;
  }

  .main-bod-con {
    width: 88%;
    background: white;
    padding: 50px;
  }
  


  .crd-for-con {
    width: 40%;
    background: #f2f2f2;
    border-radius: 10px;
    padding: 10px;
    display: inline-block;
    margin-right: 9%;
}
  .crd-con-txt {
    min-width: 100%;
    height: auto;
    padding: 20px;
    color: #2b092b;
    font-family: 'Lato', sans-serif;
    }

    .only-rw-fl {
    min-width: 100%;
    height: 10px;
    margin: 10px 0px;
    background: #d8c9cc;
    border-radius: 10px;
  }

  img.img-ico-fet-cld {
    height: 50px;

}

  .main-mac-scr{
    display: none;
  }

  .menu-head-mac-scr {
    padding: 10px;
    width: 100%;
    background: #f2f2f2;
}

ul.men-dt-crd {
    width: auto;
    background: #f2f2f2;
    width: fit-content;
    margin: auto;
    padding: 7px;
    border-radius: 10px;
    margin-top: 10px;
    text-align: left;
    }
    li.men-of-li {
    list-style: none;
    font-size: 10px;
    text-transform: uppercase;
    padding: 5px;
    font-weight: 500;
}

span.bdg-men-dt {
    padding: 5px;
    background: #777373;
    color: white;
    font-size: 10px;
    border-radius: 10px;
    font-weight: 500;
    text-transform: uppercase;

    }

    .temp-fet-lib-ico {
    width: 20%;
    height: 100px;
    background: #f2f2f2;
    border-radius: 10px;
    margin-top: 10px;
    margin-bottom: 10px;
    display: inline-flex;
    margin-right: 10px;

}

.edt-div-in-temp-fet {
    height: 100%;
    width: 59%;
    display: inline-block;

    }

    .std-div-in-temp-fet {
    height: 100%;
    width: 40%;
    display: inline-block;
    background: #f2f2f2;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 20px;
}

.btn-rect {
    height: 20px;
    width: 40px;
    background: #949090;
    border-radius: 10px;
    }
    .con-of-img-thumb {
    height: 100%;
    overflow: hidden;
}

.sml-obj-rect-height{
    width: 50px !important;
    height: 60px !important;
    background: #dcd5d5;

}

.ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
    }
    .ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
}


.pro-det-dis {
    width: 60%;
    height: 100%;
    display: inline-block;
    padding: 40px;
    }

    .pro-ico-dis {
    width: 60;
    height: 60;
    border-radius: 50%;
    background: #8c8585;
}

.pro-ana-dis-bx {
    height: 100%;
    width: 39%;
    display: inline-block;
    padding: 40px;
    }

    .ana-list-dis {
    width: 100%;
    height: 100%;
    background: #f2f2f2;
    border-radius: 10px;
}

.main-content{
    padding-top: 10vh;

margin: 0px;
    width: 100%;
    padding: 0px;

}
















.con-of-plans-of-sub {
    width: 70%;
    margin-left: auto;
    border-radius: 10px;
    box-shadow: 0 15px 35px rgb(50 50 93 / 10%), 0 5px 15px rgb(0 0 0 / 7%);
    background: white;

    }

    .head-of-sub-plan {
    font-size: 15px;
    font-weight: 500;
    text-align: center;
    padding: 35px 30px 20px;
    margin: 0 auto 20px;
    color: #24b47e;
    border-bottom: 2px solid #f6f9fc;
    line-height: 28px;
    
    text-transform: uppercase;
    letter-spacing: .025em;
}

.plan-des-sub {
    margin-bottom: 40px;
    }

    .tag-of-plan {
    color: #525f7f;
    max-width: 460px;
    padding-bottom: 20px;
    font-size: 16px;
    line-height: 29px;
    text-align: center;
    margin: 0 auto;
    padding: 0 40px 20px;
}

.dis-inln-blck {
    width: 100%;
    display: inline-flex;

}

.div-of-stat-of-plan {
    width: 50%;
    display: inline-block;
    text-align: center;
    }

    span.per-data-desg {
    font-size: 30px;
    color: black;
}

.desg-of-fet-plat {
    text-align: center;
    }

    .tag-of-fet-desg {
    padding: 10px;
}

.btn-of-plan-act {
    text-align: center;
    padding: 30px;
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
    background: aliceblue;
    }

    .main-content.row.container {
    background: url(https://res.cloudinary.com/heptera/image/upload/v1620832945/payment/5339595_cs4wef.jpg);
    height: auto;
    background-size: cover;
    padding-top: 20vh;
    z-index: -1;
}

.main-content.row.container:after {
   content: "";
    position: absolute;
    top: 70%;
    left: 0;
    height: 100%;
    width: 150%;
    background: white;
    z-index: -1;
    -webkit-transform: rotate(
348deg
);
    -moz-transform: rotate(-5deg);
    transform: rotate( 
348deg
 );
}

.con-of-pln{
    z-index: 1;
    padding: 0px;
}

.pln-of-sex-chs {
    margin-right: auto;
    margin-left: 0px;
    box-shadow: none;
    background: #32325d;
    background-image: -webkit-gradient(linear,left top,right bottom,from(#32325d),to(#29294c));
    background-image: linear-gradient(to bottom right,#32325d,#29294c);
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px;
}

tr{
    border: none;
}

a.btn-of-plan {
    text-transform: uppercase;
    border: none;
    font-weight: 700;
    letter-spacing: 1;
    }

    .td-of-wht-clr{
        color: white !important;
        border: 1px solid #373767;
    }

.head-of-pln-page {
    text-align: center;
    padding: 60px;
    color: white;
    font-size: 30px;
    width: 60%;
    margin: auto;
    letter-spacing: 1px;
    color: white;
}



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;

    }

    .head-of-pln-fet.col-lg-3.col-md-3.col-sm-12.col-xs-12 {
    font-size: 18px;

}

.more-abt-cel-pln.container {
    padding: 70px 0 90px;
    
    z-index: 1;
    }

    .txt-of-pln-info{
        text-align: center;
        margin-bottom: 30px;
    }
    .img-of-fet-50{
        height: 40px;
        margin-right: 20px !important;
    }

    .img-of-ico-fet-plt{
        height: 30px;
        margin-right: 10px;
    }

    

.mob-con-of-pln-stuct{
    display: none;
}




@media (min-width: 768px) and (max-width: 1024px) {
  
  /* CSS */


    .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}








@media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) {
  
  /* CSS */

   /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}

/* 
  ##Device = Low Resolution Tablets, Mobiles (Landscape)
  ##Screen = B/w 481px to 767px
*/

@media (min-width: 481px) and (max-width: 767px) {
  
  /* CSS */

   /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}

/* 
  ##Device = Most of the Smartphones Mobiles (Portrait)
  ##Screen = B/w 320px to 479px
*/

@media (min-width: 320px) and (max-width: 480px) {
  
  /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
   
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{
width: 90%;
    margin-bottom: 20px;
}

.head-of-pln-fet.col-lg-3.col-md-3.col-sm-12.col-xs-12 {
    text-align: center;
    padding: 20px;
  
}

.container-2GnNH {
    margin: 30px auto !important;
    }

    .tbl_of_ds_nn_in_mob{
        display: none;
    }

    .mob-con-of-pln-stuct{
        display: block;
    }

    .con-of-plans-of-sub {
    margin: 0px;
    z-index: 10000000;
    width: 90%;
    margin: auto;
    margin-bottom: 20px;

}

.head-of-pln-page {
    margin: 0px;
    padding: 0px;
    margin: auto;
    font-size: 20px;
    }

.con-of-plans-of-sub.pln-of-sex-chs {
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
}

}
</style>

<body>




<?php

require("../php/header.php");


?>




<div class="main-content row container">

<div class="head-of-pln-page">

Simple pricing pattern that helps to efficient use of your payment


</div>


<table class='tbl_of_ds_nn_in_mob' style=''>

<tbody style="
">

<tr>

<td style="
    padding: 0px;
    position: relative;
    z-index: 1;
">




<div class=" con-of-pln">

    <div class="con-of-plans-of-sub">
    
        <div class="head-of-sub-plan">
        
            Pay For Your Contact
            
        </div>
        
        <div class="plan-des-sub">

    
    
    <div class="tag-of-plan">Access full auftera plateform for your plans contact simply with Pay As Your Contact Plan Startinf at</div>
    
    <div class="dis-inln-blck">
    <div class="div-of-stat-of-plan">

    <span class="per-data-desg">1000</span><br>
    <span class="tag-of-txt-desg">For a contact multiple</span>

</div>

    
<div class="div-of-stat-of-plan">

    <span class="per-data-desg">$23</span><br>
    <span class="tag-of-txt-desg">Pay only for full plateform</span>

</div>
    </div>
</div>


<div class="desg-of-fet-plat">



<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621095450/payment/contact-book_ih0nzb.png"> 1000 contact Store In list</div>

<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621095646/payment/message_apevtt.png"> 10000 email sending</div>
<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621095789/payment/pie-chart_qcgl42.png"> 5 segment</div>
<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621095869/payment/tagged_gxwcqm.png"> 15 social Post</div>

<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621095937/payment/google_h9u9ao.png"> 3 social account</div>
<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621096004/payment/add_vcf5d0.png"> 5 App or plateform add</div>
<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621096078/payment/paper-plane_z0rnhc.png"> 10000 transactional Email</div>


<div class="tag-of-fet-desg"><img class='img-of-ico-fet-plt' src="https://res.cloudinary.com/heptera/image/upload/v1621096173/payment/database_wnkoko.png"> 1GB storage In Studio</div>

</div>
        <div class="btn-of-plan-act">

    <a href="./plateform/" class="btn-of-plan">Continue With This <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"></path>
</svg></a>

</div>
    
    </div>


</div>



</td>
<td style="
    padding: 0px;
    position: relative;
    z-index: 1;
">




<div class=" con-of-pln">






 <div class="con-of-plans-of-sub pln-of-sex-chs">
    
        <div class="head-of-sub-plan" style='color:white;border-bottom-color: rgba(85,90,191,.1);'>
        
           Enterprise
            
        </div>
        
        <div class="plan-des-sub" style='margin-bottom:0px;'>

    
    
    <div class="tag-of-plan" style='color:#aab7c4'>If you wish to edit plan as per your requirenment than choose using plan selector</div>
    

    <div class="dis-inln-blck" style="
    padding: 0px 40px;
">
   
    
    <table style="
    padding: 1;
">
    
        <tbody style="
    color: white;
">
        
            <tr>
                <td class='td-of-wht-clr' style="">Flexible</td>
                <td class='td-of-wht-clr'>feature selection</td>
            </tr>
            
            <tr>
                <td class='td-of-wht-clr'>Pay as you Go</td>
                <td class='td-of-wht-clr'>Support</td>
            </tr>
        </tbody>
    
    </table>

   
    </div>
</div>



        <div class="btn-of-plan-act" style='background:#363668;color:white;'>

    <a href="./enterprise/" class="btn-of-plan" style='color:white;'>Select requirnment <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"></path>
</svg></a>

</div>
    
    </div>


</div>




</td>

</tr>


</tbody>



</table>


























<div class="mob-con-of-pln-stuct" style="
    z-index: 1000;
">



<div>










<div class=" con-of-pln">

    <div class="con-of-plans-of-sub">
    
        <div class="head-of-sub-plan">
        
            Pay For Your Contact
            
        </div>
        
        <div class="plan-des-sub">

    
    
    <div class="tag-of-plan">Access full auftera plateform for your plans contact simply with Pay As Your Contact Plan Startinf at</div>
    
    <div class="dis-inln-blck">
    <div class="div-of-stat-of-plan">

    <span class="per-data-desg">1000</span><br>
    <span class="tag-of-txt-desg">For a contact multiple</span>

</div>

    
<div class="div-of-stat-of-plan">

    <span class="per-data-desg">$23</span><br>
    <span class="tag-of-txt-desg">Pay only for full plateform</span>

</div>
    </div>
</div>


<div class="desg-of-fet-plat">



<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621095450/payment/contact-book_ih0nzb.png"> 1000 contact Store In list</div>

<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621095646/payment/message_apevtt.png"> 10000 email sending</div>
<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621095789/payment/pie-chart_qcgl42.png"> 5 segment</div>
<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621095869/payment/tagged_gxwcqm.png"> 15 social Post</div>

<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621095937/payment/google_h9u9ao.png"> 3 social account</div>
<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621096004/payment/add_vcf5d0.png"> 5 App or plateform add</div>
<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621096078/payment/paper-plane_z0rnhc.png"> 10000 transactional Email</div>


<div class="tag-of-fet-desg"><img class="img-of-ico-fet-plt" src="https://res.cloudinary.com/heptera/image/upload/v1621096173/payment/database_wnkoko.png"> 1GB storage In Studio</div>

</div>
        <div class="btn-of-plan-act">

    <a href="./plateform/" class="btn-of-plan">Continue With This <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"></path>
</svg></a>

</div>
    
    </div>


</div>









<div class=" con-of-pln">






 <div class="con-of-plans-of-sub pln-of-sex-chs">
    
        <div class="head-of-sub-plan" style="color:white;border-bottom-color: rgba(85,90,191,.1);">
        
           Enterprise
            
        </div>
        
        <div class="plan-des-sub" style="margin-bottom:0px;">

    
    
    <div class="tag-of-plan" style="color:#aab7c4">If you wish to edit plan as per your requirenment than choose using plan selector</div>
    

    <div class="dis-inln-blck" style="
    padding: 0px 40px;
">
   
    
    <table style="
    padding: 1;
">
    
        <tbody style="
    color: white;
">
        
            <tr>
                <td class="td-of-wht-clr" style="">Flexible</td>
                <td class="td-of-wht-clr">feature selection</td>
            </tr>
            
            <tr>
                <td class="td-of-wht-clr">Pay as you Go</td>
                <td class="td-of-wht-clr">Support</td>
            </tr>
        </tbody>
    
    </table>

   
    </div>
</div>



        <div class="btn-of-plan-act" style="background:#363668;color:white;">

    <a href="./enterprise/" class="btn-of-plan" style="color:white;">Select requirnment <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor" class="bi bi-arrow-right" viewBox="0 0 16 16" style="
    margin-left: 10px;
">
  <path fill-rule="evenodd" d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"></path>
</svg></a>

</div>
    
    </div>


</div>









</div>







</div>







</div>







<div class="tag-for-pln-sub" style="
    z-index: 1;
    border-bottom:2px solid #f6f9fc;
">

<div class="container-2GnNH" style="
    width: 50%;
    margin: auto;
    border-bottom: 0px;
    margin-top: 100px;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1621093710/payment/wristwatch_izvgvi.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 60px;
    margin-right: 20px;
"><span>Fast reliable and effient way of marketing and managment of your niche. we also provide more feature <a href="">Browse feature</a></span>
</div>

</div>



<div class='more-abt-cel-pln container'>


<div class='con-of-spec-fet-dt'>

<div class="head-of-pln-fet col-lg-3 col-md-3 col-sm-12 col-xs-12">


<img class='img-of-fet-50' src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" style="
    margin-right: 10px;
">Marketing Plateform



</div>


<div class="col-lg-9 col-md-9 col-sm-12 col-sm-12 txt-of-pln-info" style="
    font-size: 14px;
    padding: 14px;

">

A complete toolkit for developer and thank you for <a href="">use it in your project</a>

</div>

</div>


<div class='main-con-of-all-fet'>


<div class='con-of-spec-fet-dt'>

<div class="head-of-pln-fet col-lg-3 col-md-3 col-sm-12 col-xs-12">


<img class='img-of-fet-50' src="https://res.cloudinary.com/heptera/image/upload/v1620921209/payment/image_1_g72ngx.png" style="
    margin-right: 10px;

">Studio For Content



</div>


<div class="col-lg-9 col-md-9 col-sm-12 col-sm-12 txt-of-pln-info" style="
    font-size: 14px;
    padding: 14px;
">

Studio is Auftera software that able to manage your content that you use at template and othet auftera plateform like social. we also provide to edit image file and ready to use at plateform <a href="">use it in your project</a>

</div>

</div>




<div class='con-of-spec-fet-dt'>

<div class="head-of-pln-fet col-lg-3 col-md-3 col-sm-12 col-xs-12">


<img class='img-of-fet-50' src="https://res.cloudinary.com/heptera/image/upload/v1620921313/payment/template_dige04.png" style="
    margin-right: 10px;
">Social Plateform



</div>


<div class="col-lg-9 col-md-9 col-sm-12 col-sm-12 txt-of-pln-info" style="
    font-size: 14px;
    padding: 14px;
">

Social plateform make user able to connect theire social media account with auftera and sheduled social post at social plateform. and also get analysis dashboard of social account.
</div>

</div>


</div>

</div>




<div class="container-2GnNH" style="
    width: 70%;
    border-bottom: 0px;
    z-index: 1;
    width: 100%;
    padding: 100px 200px;
    background: #f6f9fc;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1620922678/payment/user-interface_rpf6yn.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 100px;
    margin-right: 40px;
    padding: 20px;
"><span style='padding:0px 40px;;'>You can contact us if any confusion at your plan choosing. you are welcome for contact with us. make sure after descussion help to choose plan </span><span style="
    margin: 50px 100px;
">

    <a href="https://<br />
<b>Notice</b>:  Undefined variable: url_main in <b>/Applications/XAMPP/xamppfiles/htdocs/slp-globe/php/header.php</b> on line <b>146</b><br />
/account/signup/" class="c-button v--left v--primary" style="
    padding: 10px;
">Get started</a>

</span>
</div>


<?php require("../php/footer.php");?>
















</body>
</html>



<script type="text/javascript">




</script>