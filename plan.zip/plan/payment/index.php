<?php
use \PhpPot\Service\StripePayment;

require_once "config.php";

if (!empty($_POST["token"])) {
    require_once 'StripePayment.php';
    $stripePayment = new StripePayment();
    
    $stripeResponse = $stripePayment->chargeAmountFromCard($_POST);
    
    require_once "DBController.php";
    $dbController = new DBController();
    
    $amount = $stripeResponse["amount"] /100;
    
    $param_type = 'ssdssss';
    $param_value_array = array(
        $_POST['email'],
        $_POST['item_number'],
        $amount,
        $stripeResponse["currency"],
        $stripeResponse["balance_transaction"],
        $stripeResponse["status"],
        json_encode($stripeResponse)
    );
    $query = "INSERT INTO tbl_payment (email, item_number, amount, currency_code, txn_id, payment_status, payment_response) values (?, ?, ?, ?, ?, ?, ?)";
    $id = $dbController->insert($query, $param_type, $param_value_array);
    
    if ($stripeResponse['amount_refunded'] == 0 && empty($stripeResponse['failure_code']) && $stripeResponse['paid'] == 1 && $stripeResponse['captured'] == 1 && $stripeResponse['status'] == 'succeeded') {
        $successMessage = "Stripe payment is completed successfully. The TXN ID is " . $stripeResponse["balance_transaction"];
    }
}


$arr_of_post=json_encode($_POST);

$flg_of_tp_pay=$_GET['src_pay'];


?>
<html>
<head>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">


<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<style type="text/css">



body {
    font-family: 'lato';

    
}

.container{
    margin: auto;
}

#frmStripePayment {
    max-width: 350px;
    padding: 25px;
    border-radius: 4px;
    margin: auto;
    box-shadow: rgb(0 0 0 / 25%) 0px 25px 50px -12px;
    background: white;
}

.test-data {
    margin-top: 40px;
}

.tutorial-table {
    border: #D0D0D0 1px solid;
    font-size: 0.8em;
    color: #4e4e4e;
}

.tutorial-table th {
    background: #efefef;
    padding: 12px;
    border-bottom: #e0e0e0 1px solid;
    text-align: left;
}

.tutorial-table td {
    padding: 12px;
    border-bottom: #D0D0D0 1px solid;
}

#frmStripePayment .field-row {
    margin-bottom: 20px;
}

#frmStripePayment div label {
    margin: 5px 0px 0px 5px;
    color: #49615d;
    width: auto;
    font-size: 13px;
}

.demoInputBox {
    padding: 10px;
    border: #d0d0d0 1px solid;
    border-radius: 4px;
    background-color: #FFF;
    width: 100%;
    margin-top: 5px;
    box-sizing:border-box;
}

.demoSelectBox {
    padding: 10px;
    border: #d0d0d0 1px solid;
    border-radius: 4px;
    background-color: #FFF;
    margin-top: 5px;
}

select.demoSelectBox {
    
    margin-right: 10px;
}

.error {
    background-color: #FF6600;
    padding: 8px 10px;
    border-radius: 4px;
    font-size: 0.9em;
}

.success {
    background-color: #c3c791;
    padding: 8px 10px;
    border-radius: 4px;
    font-size: 0.9em;
}

.info {
    font-size: .8em;
    color: #FF6600;
    letter-spacing: 2px;
    padding-left: 5px;
}

.btnAction {
    background-color: #4a154b;
    padding: 10px 40px;
    color: #FFF;
    width: 100%;
    border: #4a154b 1px solid;
    border-radius: 4px;
    cursor:pointer;
    font-size: 13px;
}

.btnAction:focus {
    outline: none;
}

.column-right {
    margin-right: 6px;
}

.contact-row {
    display: inline-block;
}

.cvv-input {
    width: 60px;
}

#error-message {
    margin: 0px 0px 10px 0px;
    padding: 5px 25px;
    border-radius: 4px;
    line-height: 25px;
    font-size: 0.9em;
    color: #ca3e3e;
    border: #ca3e3e 1px solid;
    display: none;
    width: 300px;
}

#success-message {
    margin: 0px 0px 10px 0px;
    padding: 5px 25px;
    border-radius: 4px;
    line-height: 25px;
    font-size: 0.9em;
    color: #3da55d;
    border: #43b567 1px solid;
    width: 300px;
}

.display-none {
    display:none;
}

#response-container {
    padding: 40px 20px;
    width: 270px;
    text-align:center;
}


.ack-message {
    font-size: 1.5em;
    margin-bottom: 20px;
}

#response-container.success {
    border-top: #b0dad3 2px solid;
    background: #e9fdfa;
}

#response-container.error {
    border-top: #c3b4b4 2px solid;
    background: #f5e3e3;
}

.img-response {
    margin-bottom: 30px;
}

#loader {
    display: none;
}

#loader img {
    width: 45px;
    vertical-align: middle;
}


.con-of-pay-fld {
    padding-top: 15vh;
    height: 100vh;
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1620794519/payment/image-from-rawpixel-id-1234930-png_1_lrlhpj.png);
    background-size: contain;
    background-repeat: no-repeat;
}


.payment-serv_show {
    max-height: 50vh;
    overflow: scroll;
    margin-top: 30px;
    margin-bottom: 30px;
}

.sel_serv_def_dsg {
    padding: 10px 30px 20px 30px;
    margin: 20px;
    background: white;
    border-radius: 20px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-left: 4px;
}

.serv_head_name {
    font-weight: 700;
    font-family: 'Lato';
    color: #7b2759;
    }
    span.ret-to-chg {
    float: right;
    color: #4a154b;
    font-size: 12px;
}
.calc-of-serv-quan {
    padding-top: 20px;
    }

    span.tot-of-calc-dt {
    float: right;
}

.payment-serv_show::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.payment-serv_show {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.tot-of-plan {
    margin: 4px;
    border-radius: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 6px 12px -2px, rgb(0 0 0 / 30%) 0px 3px 7px -3px;
    background: green;
    color: white;
    padding: 20px;
    }

    span.plan-con-def {
    float: right;
}


.ip-by-def-dsg:focus{
    background-color: #fff;
    outline: 0;
    border-color: #4a154b;
    box-shadow: 0 0 0 3px #4a154b4d;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
}



</style>
</head>
<body>


    <?php if(!empty($successMessage)) { ?>
    <div id="success-message"><?php echo $successMessage; ?></div>
    <?php  } ?>
    <div id="error-message"></div>
                
<div class="container row">
 

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 con-of-pay-page-land" style="
    padding: 10vh;
">




<svg width="385" height="47" xmlns="http://www.w3.org/2000/svg" style="margin-left: 10px;">
 <g id="Layer_1">
  <title>Layer 1</title>
  <text font-style="normal" font-weight="normal" stroke="#000" xml:space="preserve" text-anchor="start" font-family="''Nunito', sans-serif'" font-size="35" id="svg_2" y="35" x="0" stroke-width="0" fill="#611f69" style="font-weight:800">Auftera</text>
  <text font-style="normal" font-weight="normal" xml:space="preserve" text-anchor="start" font-family="''Nunito', sans-serif'" font-size="24" id="svg_4" y="35" x="136" stroke-width="0" stroke="#000" fill="#611f69" style="font-weight:600">Marketing</text>
  <text stroke-dasharray="2,2" font-style="normal" font-weight="normal" xml:space="preserve" text-anchor="start" font-family="''Nunito', sans-serif'" font-size="24" id="svg_5" y="35" x="271" stroke-width="0" stroke="#000" fill="#611f69">Plateform</text>
 </g>

</svg>


<div class="payment-serv_show">

   







</div>


<div class="tot-of-plan">

    <div class="plan-amm">Selected Plan Cost <span class="plan-con-def">$<span id='tot-cost-of-fin-sel-pln'>40</span></span></div>


</div>

</div>

<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 con-of-pay-fld">
            <form id="frmStripePayment" action=""
                method="post">



<div class="field-row" style='display:none;'>
                    <label>Email</label> <span id="email-info"
                        class="info"></span><br> <input id='pln_fin_prc' type="number"
                        name='pln_prc' >
                </div>



                <div class="field-row">
                    <label>Card Holder Name</label> <span
                        id="card-holder-name-info" class="info"></span><br>
                    <input type="text" id="name" name="name"
                        class="demoInputBox ip-by-def-dsg">
                </div>
                <div class="field-row">
                    <label>Email</label> <span id="email-info"
                        class="info"></span><br> <input type="text"
                        id="email" name="email" class="demoInputBox ip-by-def-dsg">
                </div>
                <div class="field-row">
                    <label>Card Number</label> <span
                        id="card-number-info" class="info"></span><br> <input
                        type="text" id="card-number" name="card-number"
                        class="demoInputBox ip-by-def-dsg">
                </div>
                <div class="field-row">
                    <div class="contact-row column-right">
                        <label>Expiry Month / Year</label> <span
                            id="userEmail-info" class="info"></span><br>
                        <select name="month" id="month"
                            class="demoSelectBox ip-by-def-dsg">
                            <option value="08">08</option>
                            <option value="09">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                        </select> <select name="year" id="year"
                            class="demoSelectBox ip-by-def-dsg">
                            <option value="18">2018</option>
                            <option value="19">2019</option>
                            <option value="20">2020</option>
                            <option value="21">2021</option>
                            <option value="22">2022</option>
                            <option value="23">2023</option>
                            <option value="24">2024</option>
                            <option value="25">2025</option>
                            <option value="26">2026</option>
                            <option value="27">2027</option>
                            <option value="28">2028</option>
                            <option value="29">2029</option>
                            <option value="30">2030</option>
                        </select>
                    </div>
                    <div class="contact-row cvv-box ">
                        <label>CVC</label> <span id="cvv-info"
                            class="info"></span><br> <input type="text"
                            name="cvc" id="cvc"
                            class="demoInputBox cvv-input ip-by-def-dsg">
                    </div>
                </div>
                <div>
                    <input type="submit" name="pay_now" value="Submit"
                        id="submit-btn" class="btnAction"
                        onClick="stripePay(event);">

                    <div id="loader">
                        <img alt="loader" src="LoaderIcon.gif">
                    </div>
                </div>
                <input type='hidden' name='amount' value='0.5'> <input
                    type='hidden' name='currency_code' value='USD'> <input
                    type='hidden' name='item_name' value='Test Product'>
                <input type='hidden' name='item_number'
                    value='PHPPOTEG#1'>
            </form>


            </div>
</div>
    
    <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"
        type="text/javascript"></script>
    <script>
function cardValidation () {
    var valid = true;
    var name = $('#name').val();
    var email = $('#email').val();
    var cardNumber = $('#card-number').val();
    var month = $('#month').val();
    var year = $('#year').val();
    var cvc = $('#cvc').val();

    $("#error-message").html("").hide();

    if (name.trim() == "") {
        valid = false;
    }
    if (email.trim() == "") {
    	   valid = false;
    }
    if (cardNumber.trim() == "") {
    	   valid = false;
    }

    if (month.trim() == "") {
    	    valid = false;
    }
    if (year.trim() == "") {
        valid = false;
    }
    if (cvc.trim() == "") {
        valid = false;
    }

    if(valid == false) {
        $("#error-message").html("All Fields are required").show();
    }

    return valid;
}
//set your publishable key
Stripe.setPublishableKey("<?php echo STRIPE_PUBLISHABLE_KEY; ?>");

//callback to handle the response from stripe
function stripeResponseHandler(status, response) {
    if (response.error) {
        //enable the submit button
        $("#submit-btn").show();
        $( "#loader" ).css("display", "none");
        //display the errors on the form
        $("#error-message").html(response.error.message).show();
    } else {
        //get token id
        var token = response['id'];
        //insert the token into the form
        $("#frmStripePayment").append("<input type='hidden' name='token' value='" + token + "' />");
        //submit form to the server
        $("#frmStripePayment").submit();
    }
}
function stripePay(e) {
    e.preventDefault();
    var valid = cardValidation();

    if(valid == true) {
        $("#submit-btn").hide();
        $( "#loader" ).css("display", "inline-block");
        Stripe.createToken({
            number: $('#card-number').val(),
            cvc: $('#cvc').val(),
            exp_month: $('#month').val(),
            exp_year: $('#year').val()
        }, stripeResponseHandler);

        //submit from callback
        return false;
    }
}

def_of_all_opt=[];



arr_of_req_data=JSON.parse('<?php echo $arr_of_post;?>');

flg_of_src_pay='<?php echo $flg_of_tp_pay;?>';

console.log(arr_of_req_data);



function add_all_chs_pln(arr_data){

str_of_app="";
def_of_all_opt=arr_data;

prc_of_pln=0;


for (var i = 0; i < 8; i++) {
   data_of_loc= arr_data[i]



if(data_of_loc['mult_oth_fact']==undefined){

ast_prc=(arr_of_req_data[i]*data_of_loc['con_mult_fact']);

}else{

ast_prc=(arr_of_req_data[i]*data_of_loc['con_mult_fact'])*arr_data[data_of_loc['mult_oth_fact']]['value_con'];


}

ast_prc=Math.round((ast_prc + Number.EPSILON) * 100) / 100;
prc_of_pln+=ast_prc;


str_of_app+='<div class="sel_serv_def_dsg"> <span class="serv_head_name"> '+data_of_loc['name']+' </span><span class="ret-to-chg">Back To Change</span> <div class="calc-of-serv-quan"> <span id="txt-of-quntity-fet">'+arr_of_req_data[i]+'</span> <span class="tot-of-calc-dt">$'+ast_prc+'</span> </div> </div>';

};


prc_of_pln=Math.round((prc_of_pln + Number.EPSILON) * 100) / 100;

$("#tot-cost-of-fin-sel-pln").html(prc_of_pln);

$("#pln_fin_prc").val(prc_of_pln);


$(".payment-serv_show").append(str_of_app);

}




function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      
      add_all_chs_pln(JSON.parse(this.responseText));
    }
  };
  xhttp.open("GET", "../enterprise/data_of_pln.json", true);
  xhttp.send();
}

if(flg_of_src_pay=='ent'){

loadDoc();
}else if(flg_of_src_pay=='plt'){

console.log(arr_of_req_data);

sel_qnt_of_con=arr_of_req_data['pln_tms_sel_nm'];



val_of_pln_cst=((24*sel_qnt_of_con)-(sel_qnt_of_con*1));


str_of_app='<div class="sel_serv_def_dsg"> <span class="serv_head_name"> Contact </span><span class="ret-to-chg">Back To Change</span> <div class="calc-of-serv-quan"> <span id="txt-of-quntity-fet">'+sel_qnt_of_con+'</span> <span class="tot-of-calc-dt">$'+val_of_pln_cst+'</span> </div> </div>';




$("#tot-cost-of-fin-sel-pln").html(val_of_pln_cst);

$("#pln_fin_prc").val(val_of_pln_cst);


$(".payment-serv_show").append(str_of_app);



}


</script>
</body>
</html>