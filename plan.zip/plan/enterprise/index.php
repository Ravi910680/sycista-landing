<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>
</head>

<link rel="stylesheet" type="text/css" href="../../css/main.css">

<style type="text/css">


body{
    font-family: 'lato' !important;
letter-spacing:0.2px;
}

table{
    font-family: 'lato';
}

a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.c-nav--primary {
    padding: 0;
    height: 10vh;
    background-color: #fff;
    border-bottom: 1px solid #ebeaeb;
    z-index: 1000;
    top: 0;
    position: fixed;

  }
.c-slacklogo{
    width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
    font-weight: 400;
}

.main-conetent{
    margin-top: 10vh;

  }

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}


.row{
    margin: 0px;
}
.rw-mini-con{
    padding: 100px 80px;
}

.col-txt-of-rw{
    padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

    background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }

    .txt_alg_cnt{
        text-align: center;
    }


    .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

    .col_height_300{
        min-height: 350px;
    }








    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
}




.rw-mini-con {
    padding: 100px 80px;
   
    overflow: scroll;
  }
  

  .div-dsgn {
    text-align: center;
    margin: 20px 0px;
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1612195541/landing/Horiz-line_tgfmhw.jpg);
    background-size: contain;
  }
  .div-txt-con.c-billboard__kicker.c-billboard__kicker__text.u-text--uppercase {
    text-align: center;
    color: white;
    background: #4a154b;
    padding: 10px;
    border-radius: 1000px;
  }


  li.fet-btn-li {
    list-style: none;
    padding: 10px;
    font-size: 15px;
    font-weight: 600;
    font-family: 'Lato', sans-serif;
    border: 2px solid #611f69;
    border-radius: 10px;
    margin-top: 10px;
  }

  ul.ul-lst-of-fet {
    width: 300px;
    border-radius: 10px;
    
  }

  .fet-btn-li-act{
    background: #611f69;
    color: white;
  }

  .main-mac-scr {
    border-radius: 10px;
    background: #2b092b;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
    border-right: none !important;
  }
  .rw-mini-con {
    padding: 80px 0px;
    overflow: scroll;
  }
  
  li.li-fr-side-nav {
    list-style: none;
    padding: 10px;
  }
  .main-bod-con {
    width: 88%;
    height: 300px;
    background: white;
  }

  .main-bod-con {
    width: 88%;
    background: white;
    padding: 50px;
  }
  


  .crd-for-con {
    width: 40%;
    background: #f2f2f2;
    border-radius: 10px;
    padding: 10px;
    display: inline-block;
    margin-right: 9%;
}
  .crd-con-txt {
    min-width: 100%;
    height: auto;
    padding: 20px;
    color: #2b092b;
    font-family: 'Lato', sans-serif;
    }

    .only-rw-fl {
    min-width: 100%;
    height: 10px;
    margin: 10px 0px;
    background: #d8c9cc;
    border-radius: 10px;
  }

  img.img-ico-fet-cld {
    height: 50px;

}

  .main-mac-scr{
    display: none;
  }

  .menu-head-mac-scr {
    padding: 10px;
    width: 100%;
    background: #f2f2f2;
}

ul.men-dt-crd {
    width: auto;
    background: #f2f2f2;
    width: fit-content;
    margin: auto;
    padding: 7px;
    border-radius: 10px;
    margin-top: 10px;
    text-align: left;
    }
    li.men-of-li {
    list-style: none;
    font-size: 10px;
    text-transform: uppercase;
    padding: 5px;
    font-weight: 500;
}

span.bdg-men-dt {
    padding: 5px;
    background: #777373;
    color: white;
    font-size: 10px;
    border-radius: 10px;
    font-weight: 500;
    text-transform: uppercase;

    }

    .temp-fet-lib-ico {
    width: 20%;
    height: 100px;
    background: #f2f2f2;
    border-radius: 10px;
    margin-top: 10px;
    margin-bottom: 10px;
    display: inline-flex;
    margin-right: 10px;

}

.edt-div-in-temp-fet {
    height: 100%;
    width: 59%;
    display: inline-block;

    }

    .std-div-in-temp-fet {
    height: 100%;
    width: 40%;
    display: inline-block;
    background: #f2f2f2;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 20px;
}

.btn-rect {
    height: 20px;
    width: 40px;
    background: #949090;
    border-radius: 10px;
    }
    .con-of-img-thumb {
    height: 100%;
    overflow: hidden;
}

.sml-obj-rect-height{
    width: 50px !important;
    height: 60px !important;
    background: #dcd5d5;

}

.ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
    }
    .ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
}


.pro-det-dis {
    width: 60%;
    height: 100%;
    display: inline-block;
    padding: 40px;
    }

    .pro-ico-dis {
    width: 60;
    height: 60;
    border-radius: 50%;
    background: #8c8585;
}

.pro-ana-dis-bx {
    height: 100%;
    width: 39%;
    display: inline-block;
    padding: 40px;
    }

    .ana-list-dis {
    width: 100%;
    height: 100%;
    background: #f2f2f2;
    border-radius: 10px;
}

.main-content{
    padding-top: 10vh;

margin: 0px;
    width: 100%;
    padding: 0px;

}
















.con-of-plans-of-sub {
    width: 70%;
    margin-left: auto;
    border-radius: 10px;
    box-shadow: 0 15px 35px rgb(50 50 93 / 10%), 0 5px 15px rgb(0 0 0 / 7%);
    background: white;

    }

    .head-of-sub-plan {
    font-size: 15px;
    font-weight: 500;
    text-align: center;
    padding: 35px 30px 20px;
    margin: 0 auto 20px;
    color: #24b47e;
    border-bottom: 2px solid #f6f9fc;
    line-height: 28px;
    
    text-transform: uppercase;
    letter-spacing: .025em;
}

.plan-des-sub {
    margin-bottom: 40px;
    }

    .tag-of-plan {
    color: #525f7f;
    max-width: 460px;
    padding-bottom: 20px;
    font-size: 16px;
    line-height: 29px;
    text-align: center;
    margin: 0 auto;
    padding: 0 40px 20px;
}

.dis-inln-blck {
    width: 100%;
    display: inline-flex;

}

.div-of-stat-of-plan {
    width: 50%;
    display: inline-block;
    text-align: center;
    }

    span.per-data-desg {
    font-size: 30px;
    color: black;
}

.desg-of-fet-plat {
    text-align: center;
    }

    .tag-of-fet-desg {
    padding: 10px;
}

.btn-of-plan-act {
    text-align: center;
    padding: 30px;
    border-bottom-right-radius: 10px;
    border-bottom-left-radius: 10px;
    background: aliceblue;
    }

    .main-content.row.container {
   
   background: url(https://res.cloudinary.com/heptera/image/upload/v1620967305/payment/ebe1bdfb2e6_jbh4o9.jpg);
    
   
    padding-top: 10vh;
}

.main-content.row.container:after {
   content: "";
    position: absolute;
    top: 70%;
    left: 0;
    height: 100%;
    width: 150%;
    background: white;
    -webkit-transform: rotate(
348deg
);
    -moz-transform: rotate(-5deg);
    transform: rotate( 
348deg
 );
}

.con-of-pln{
    z-index: 1;
    padding: 0px;
}

.pln-of-sex-chs {
    margin-right: auto;
    margin-left: 0px;
    box-shadow: none;
    background: #32325d;
    background-image: -webkit-gradient(linear,left top,right bottom,from(#32325d),to(#29294c));
    background-image: linear-gradient(to bottom right,#32325d,#29294c);
    border-top-left-radius: 0px;
    border-bottom-left-radius: 0px;
}

tr{
    border: none;
}

a.btn-of-plan {
    text-transform: uppercase;
    border: none;
    font-weight: 700;
    letter-spacing: 1;
    }

    .td-of-wht-clr{
        color: white !important;
        border: 1px solid #373767;
    }

.head-of-pln-page {
    text-align: center;
    padding: 60px;
    color: white;
    font-size: 30px;
    width: 60%;
    margin: auto;
    letter-spacing: 1px;
    color: white;
}



.container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 30px 36px;
    border-bottom: 1px solid #dedddc;

    }

    .head-of-pln-fet.col-lg-3.col-md-3.col-sm-12.col-xs-12 {
    font-size: 18px;

}

.more-abt-cel-pln.container {
    padding: 70px 0 90px;
    
    z-index: 1;
    }

    .txt-of-pln-info{
        text-align: center;
        margin-bottom: 30px;
    }
    .img-of-fet-50{
        height: 40px;
        margin-right: 20px !important;
    }












.range-slider.grad {
  --progress-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2) inset;
  --progress-flll-shadow: var(--progress-shadow);
  --fill-color: linear-gradient(to right, LightCyan, var(--primary-color));
  --thumb-shadow: 0 0 4px rgba(0, 0, 0, 0.3),
    -3px 9px 9px rgba(255, 255, 255, 0.33) inset,
    -1px 3px 2px rgba(255, 255, 255, 0.33) inset,
    0 0 0 99px var(--primary-color) inset;
}
.range-slider.grad input:hover {
  --thumb-transform: scale(1.2);
}
.range-slider.grad input:active {
  --thumb-shadow: inherit;
  --thumb-transform: scale(1);
}

.range-slider.flat {
  --thumb-size: 25px;
  --track-height: calc(var(--thumb-size) / 3);
  --progress-shadow: none;
  --progress-flll-shadow: none;
  --thumb-shadow: 0 0 0 7px var(--primary-color) inset, 0 0 0 99px white inset;
  --thumb-shadow-hover: 0 0 0 9px var(--primary-color) inset,
    0 0 0 99px white inset;
  --thumb-shadow-active: 0 0 0 13px var(--primary-color) inset;
}

.range-slider.overlay {
  --primary-color: #d6e9ff;
  --track-height: 50px;
  --thumb-size: var(--track-height);
  --thumb-color: var(--primary-color);
  --thumb-shadow: none;
  --progress-flll-shadow: none;
  --progress-shadow: none;
  --progress-background: none;
  --progress-radius: 0px;
  --ticks-color: var(--primary-color);
  --ticks-height: 0;
  --ticks-thickness: 0;
  --ticks-gap: 0px;
  --min-max-font: 700 18px Arial;
  --min-max-opacity: 1;
  --show-min-max: none;
  color: #0366d6;
}
.range-slider.overlay input:hover {
  --thumb-shadow: calc(25px - (50px * var(--is-left-most))) 0 0 -15px #0366d6
    inset;
}
.range-slider.overlay input:active {
  --thumb-color: inherit;
}
.range-slider.overlay .range-slider__values {
  width: calc(100% - 50% / (var(--max) - var(--min)));
}

.range-slider {
  --primary-color: #0366d6;
  --value-offset-y: var(--ticks-gap);
  --value-active-color: white;
  --value-background: transparent;
  --value-background-hover: var(--primary-color);
  --value-font: 700 12px/1 Arial;
  --fill-color: var(--primary-color);
  --progress-background: #eee;
  --progress-radius: 20px;
  --track-height: calc(var(--thumb-size) / 2);
  --min-max-font: 12px Arial;
  --min-max-opacity: 0.5;
  --min-max-x-offset: 10%;
  --thumb-size: 22px;
  --thumb-color: white;
  --thumb-shadow: 0 0 3px rgba(0, 0, 0, 0.4), 0 0 1px rgba(0, 0, 0, 0.5) inset,
    0 0 0 99px var(--thumb-color) inset;
  --thumb-shadow-active: 0 0 0 calc(var(--thumb-size) / 4) inset
      var(--thumb-color),
    0 0 0 99px var(--primary-color) inset, 0 0 3px rgba(0, 0, 0, 0.4);
  --thumb-shadow-hover: var(--thumb-shadow);
  --ticks-thickness: 1px;
  --ticks-height: 5px;
  --ticks-gap: var(
    --ticks-height,
    0
  );
  --ticks-color: silver;
  --step: 1;
  --ticks-count: Calc(var(--max) - var(--min)) / var(--step);
  --maxTicksAllowed: 30;
  --too-many-ticks: Min(1, Max(var(--ticks-count) - var(--maxTicksAllowed), 0));
  --x-step: Max(
    var(--step),
    var(--too-many-ticks) * (var(--max) - var(--min))
  );
  --tickInterval: 100/ ((var(--max) - var(--min)) / var(--step)) * var(--tickEvery, 1);
  --tickIntervalPerc: calc(
    (100% - var(--thumb-size)) / ((var(--max) - var(--min)) / var(--x-step)) *
      var(--tickEvery, 1)
  );
  --value-a: Clamp(
    var(--min),
    var(--value, 0),
    var(--max)
  );
  --value-b: var(--value, 0);
  --text-value-a: var(--text-value, "");
  --completed-a: calc(
    (var(--value-a) - var(--min)) / (var(--max) - var(--min)) * 100
  );
  --completed-b: calc(
    (var(--value-b) - var(--min)) / (var(--max) - var(--min)) * 100
  );
  --ca: Min(var(--completed-a), var(--completed-b));
  --cb: Max(var(--completed-a), var(--completed-b));
  --thumbs-too-close: Clamp(
    -1,
    1000 * (Min(1, Max(var(--cb) - var(--ca) - 5, -1)) + 0.001),
    1
  );
  --thumb-close-to-min: Min(1, Max(var(--ca) - 2, 0));
  --thumb-close-to-max: Min(1, Max(98 - var(--cb), 0));
  display: inline-block;
  height: max(var(--track-height), var(--thumb-size));
  background: linear-gradient(to right, var(--ticks-color) var(--ticks-thickness), transparent 1px) repeat-x;
  background-size: var(--tickIntervalPerc) var(--ticks-height);
  background-position-x: calc( var(--thumb-size) / 2 - var(--ticks-thickness) / 2 );
  background-position-y: var(--flip-y, bottom);
  padding-bottom: var(--flip-y, var(--ticks-gap));
  padding-top: calc(var(--flip-y) * var(--ticks-gap));
  position: relative;
  z-index: 1;
}
.range-slider[data-ticks-position=top] {
  --flip-y: 1;
}
.range-slider::before, .range-slider::after {
  --offset: calc(var(--thumb-size) / 2);
  content: counter(x);
  display: var(--show-min-max, block);
  font: var(--min-max-font);
  position: absolute;
  bottom: var(--flip-y, -2.5ch);
  top: calc(-2.5ch * var(--flip-y));
  opacity: clamp(0, var(--at-edge), var(--min-max-opacity));
  transform: translateX(calc(var(--min-max-x-offset) * var(--before, -1) * -1)) scale(var(--at-edge));
  pointer-events: none;
}
.range-slider::before {
  --before: 1;
  --at-edge: var(--thumb-close-to-min);
  counter-reset: x var(--min);
  left: var(--offset);
}
.range-slider::after {
  --at-edge: var(--thumb-close-to-max);
  counter-reset: x var(--max);
  right: var(--offset);
}
.range-slider__values {
  position: relative;
  top: 50%;
  line-height: 0;
  text-align: justify;
  width: 100%;
  pointer-events: none;
  margin: 0 auto;
  z-index: 5;
}
.range-slider__values::after {
  content: "";
  width: 100%;
  display: inline-block;
  height: 0;
  background: red;
}
.range-slider__progress {
  --start-end: calc(var(--thumb-size) / 2);
  --clip-end: calc(100% - (var(--cb)) * 1%);
  --clip-start: calc(var(--ca) * 1%);
  --clip: inset(-20px var(--clip-end) -20px var(--clip-start));
  position: absolute;
  left: var(--start-end);
  right: var(--start-end);
  top: calc( var(--ticks-gap) * var(--flip-y, 0) + var(--thumb-size) / 2 - var(--track-height) / 2 );
  height: calc(var(--track-height));
  background: var(--progress-background, #eee);
  pointer-events: none;
  z-index: -1;
  border-radius: var(--progress-radius);
}
.range-slider__progress::before {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  -webkit-clip-path: var(--clip);
          clip-path: var(--clip);
  top: 0;
  bottom: 0;
  background: var(--fill-color, black);
  box-shadow: var(--progress-flll-shadow);
  z-index: 1;
  border-radius: inherit;
}
.range-slider__progress::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  box-shadow: var(--progress-shadow);
  pointer-events: none;
  border-radius: inherit;
}
.range-slider > input {
  -webkit-appearance: none;
  width: 100%;
  height: var(--thumb-size);
  margin: 0;
  position: absolute;
  left: 0;
  top: calc( 50% - Max(var(--track-height), var(--thumb-size)) / 2 + calc(var(--ticks-gap) / 2 * var(--flip-y, -1)) );
  cursor: -webkit-grab;
  cursor: grab;
  outline: none;
  background: none;
}
.range-slider > input:not(:only-of-type) {
  pointer-events: none;
}
.range-slider > input::-webkit-slider-thumb {
  -webkit-appearance: none;
          appearance: none;
  height: var(--thumb-size);
  width: var(--thumb-size);
  transform: var(--thumb-transform);
  border-radius: var(--thumb-radius, 50%);
  background: var(--thumb-color);
  box-shadow: var(--thumb-shadow);
  border: none;
  pointer-events: auto;
  -webkit-transition: 0.1s;
  transition: 0.1s;
}
.range-slider > input::-moz-range-thumb {
  -moz-appearance: none;
       appearance: none;
  height: var(--thumb-size);
  width: var(--thumb-size);
  transform: var(--thumb-transform);
  border-radius: var(--thumb-radius, 50%);
  background: var(--thumb-color);
  box-shadow: var(--thumb-shadow);
  border: none;
  pointer-events: auto;
  -moz-transition: 0.1s;
  transition: 0.1s;
}
.range-slider > input::-ms-thumb {
  appearance: none;
  height: var(--thumb-size);
  width: var(--thumb-size);
  transform: var(--thumb-transform);
  border-radius: var(--thumb-radius, 50%);
  background: var(--thumb-color);
  box-shadow: var(--thumb-shadow);
  border: none;
  pointer-events: auto;
  -ms-transition: 0.1s;
  transition: 0.1s;
}
.range-slider > input:hover {
  --thumb-shadow: var(--thumb-shadow-hover);
}
.range-slider > input:hover + output {
  --value-background: var(--value-background-hover);
  --y-offset: -5px;
  color: var(--value-active-color);
  box-shadow: 0 0 0 3px var(--value-background);
}
.range-slider > input:active {
  --thumb-shadow: var(--thumb-shadow-active);
  cursor: -webkit-grabbing;
  cursor: grabbing;
  z-index: 2;
}
.range-slider > input:active + output {
  transition: 0s;
}
.range-slider > input:nth-of-type(1) {
  --is-left-most: Clamp(0, (var(--value-a) - var(--value-b)) * 99999, 1);
}
.range-slider > input:nth-of-type(1) + output {
  --value: var(--value-a);
  --x-offset: calc(var(--completed-a) * -1%);
}
.range-slider > input:nth-of-type(1) + output:not(:only-of-type) {
  --flip: calc(var(--thumbs-too-close) * -1);
}
.range-slider > input:nth-of-type(1) + output::after {
  content: var(--prefix, "") var(--text-value-a) var(--suffix, "");
}
.range-slider > input:nth-of-type(2) {
  --is-left-most: Clamp(0, (var(--value-b) - var(--value-a)) * 99999, 1);
}
.range-slider > input:nth-of-type(2) + output {
  --value: var(--value-b);
}
.range-slider > input:only-of-type ~ .range-slider__progress {
  --clip-start: 0;
}
.range-slider > input + output {
  --flip: -1;
  --x-offset: calc(var(--completed-b) * -1%);
  --pos: calc(
    ((var(--value) - var(--min)) / (var(--max) - var(--min))) * 100%
  );
  pointer-events: none;
  position: absolute;
  z-index: 5;
  background: var(--value-background);
  border-radius: 10px;
  padding: 2px 4px;
  left: var(--pos);
  transform: translate(var(--x-offset), calc( 150% * var(--flip) - (var(--y-offset, 0px) + var(--value-offset-y)) * var(--flip) ));
  transition: all 0.12s ease-out, left 0s;
}
.range-slider > input + output::after {
  content: var(--prefix, "") var(--text-value-b) var(--suffix, "");
  font: var(--value-font);
}

@media screen and (max-width: 500px) {
 
}


@media screen and (max-width: 500px) {
  a {
    position: static;
    order: -1;
  }
}
a > img {
  display: inherit;
  height: 100%;
}

body > .range-slider,
label[dir=rtl] .range-slider {
  width: clamp(300px, 50vw, 800px);
  min-width: 200px;
}
















.all-pln-con {
    width: 100%;
    height: max-content;
    display: grid;
    margin-bottom: 100px;

    }

    .pln-sel-of-dt {
    margin: auto;
    padding: 10px 40px 10px;
    background: white;
    border-radius: 4px;
    display: flex;
    box-shadow: rgb(50 50 93 / 25%) 0px 13px 27px -5px, rgb(0 0 0 / 30%) 0px 8px 16px -8px;
    margin-top: 40px;
    z-index: 1;
}

.email-txt-sel-dt-avl {
    color: white;
    padding-bottom: 30px;
    width: 60%;
    display: inline-block;


    }

    .head-of-sld-txt {
    padding: 10px 10px 30;
    font-weight: 700;
    color: #611f69;
}

.sldr-con {
    display: inline-block;
    width: 100%;

    }

    .other-con-of-cst {
    text-align: center;
    width: 30%;
    display: inline-block;
    border-left: 1px solid #a5a9ad;
    margin-left: auto;
    padding: 19px;
}
span.cst-of-pln {
    font-size: 40px;
    }

    span.txt-of-cst-res {
    color: grey;
    font-weight: 700;
    font-size: 12px;
}


.tot-of-pln-cst {
    display: contents;
    margin-bottom: 100px;


    }

    .plan-cst-lst-tot-con {
    font-size: 40px;
}










@media (min-width: 768px) and (max-width: 1024px) {
  
  /* CSS */


    .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}








@media (min-width: 768px) and (max-width: 1024px) and (orientation: landscape) {
  
  /* CSS */

   /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}

/* 
  ##Device = Low Resolution Tablets, Mobiles (Landscape)
  ##Screen = B/w 481px to 767px
*/

@media (min-width: 481px) and (max-width: 767px) {
  
  /* CSS */

   /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
    background: #f6f9fc;
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{

    margin-bottom: 20px;
}
  
}

/* 
  ##Device = Most of the Smartphones Mobiles (Portrait)
  ##Screen = B/w 320px to 479px
*/

@media (min-width: 320px) and (max-width: 480px) {
  
  /* CSS */
  .main-content.row.container:after{
    width: 0px;
  }

  img.icon-1sM2z {
    margin: auto !important;
}

.container-2GnNH{

padding: 0px !important;
   
    display: grid;
    text-align: center;
}

.container-2GnNH{

}

.head-of-pln-page{
width: 90%;
    margin-bottom: 20px;
}

.head-of-pln-fet.col-lg-3.col-md-3.col-sm-12.col-xs-12 {
    text-align: center;
    padding: 20px;
  
}

.container-2GnNH {
    margin: 30px auto !important;
    }

    .tbl_of_ds_nn_in_mob{
        display: none;
    }

    .mob-con-of-pln-stuct{
        display: block;
    }

    .con-of-plans-of-sub {
    margin: 0px;
    z-index: 10000000;
    width: 90%;
    margin: auto;
    margin-bottom: 20px;

}
.tot-dsg-for-mob{
    padding: 37px 10px !important;
}

}











</style>

<body>




<?php

require("../../php/header.php");


?>




<div class="main-content row container">

<div class="head-of-pln-page">

New Way to explore your fund and invest as per your requirnment


</div>



<div class="all-pln-con">
















    
</div>




</div>










<div class="container-2GnNH" style="
    width: 70%;
    border-bottom: 0px;
    z-index: 1;
    width: 100%;
    padding: 100px 200px;
    background: #f6f9fc;
"><img src="https://res.cloudinary.com/heptera/image/upload/v1620922678/payment/user-interface_rpf6yn.png" alt="" role="presentation" class="icon-1sM2z" style="
    width: 100px;
    margin-right: 40px;
    padding: 20px;
"><span style='padding:0px 40px;;'>You can contact us if any confusion at your plan choosing. you are welcome for contact with us. make sure after descussion help to choose plan </span><span style="
    margin: 50px 100px;
">

    <a href="https://<br />
<b>Notice</b>:  Undefined variable: url_main in <b>/Applications/XAMPP/xamppfiles/htdocs/slp-globe/php/header.php</b> on line <b>146</b><br />
/account/signup/" class="c-button v--left v--primary" style="
    padding: 10px;
">Get started</a>

</span>
</div>


<?php require("../../php/footer.php");?>
















</body>
</html>



<script type="text/javascript">










function rem_all_sld_tp(tp_sld){


$("."+tp_sld).map(function() {

$(this).css('display','none');
 

});


}



function add_trg_act(tp_sld){


$("."+tp_sld).map(function() {

$(this).removeClass("fet-btn-li-act");
 

});


}

$(document).on('click','.fet-btn-li',function(){


rem_all_sld_tp($(this).attr("data-con-tp")+"-sld");


add_trg_act($(this).attr("data-con-tp")+"-sld-trg");

$(this).addClass("fet-btn-li-act");
con_sld=$(this).attr('data-trg-con')+"-sld";

$('#'+con_sld).toggle('slide', { direction: 'right'}, 500);

})



// These slider range component was used in my other component:
// https://github.com/yairEO/color-picker

var settings = {
  visible: 0, 
  theme: {
    backgroud: "rgba(0,0,0,.9)",
  },
  CSSVarTarget: document.querySelector('.range-slider'),
  knobs: [
    "Thumb",
    {
      cssVar: ['thumb-size', 'px'],
      label: 'thumb-size',
      type: 'range',
      min: 6, max: 33 //  value: 16,
    },
    "Value",
    {
      cssVar: ['value-active-color'], // alias for the CSS variable
      label: 'value active color',
      type: 'color',
      value: 'white'
    },
    {
      cssVar: ['value-background'], // alias for the CSS variable
      label: 'value-background',
      type: 'color',
    },
    {
      cssVar: ['value-background-hover'], // alias for the CSS variable
      label: 'value-background-hover',
      type: 'color',
    },
    {
      cssVar: ['primary-color'], // alias for the CSS variable
      label: 'primary-color',
      type: 'color',
    },
    {
      cssVar: ['value-offset-y', 'px'],
      label: 'value-offset-y',
      type: 'range', value: 5, min: -10, max: 20
    },
    "Track",
    {
      cssVar: ['track-height', 'px'],
      label: 'track-height',
      type: 'range', value: 8, min: 6, max: 33
    },
    {
      cssVar: ['progress-radius', 'px'],
      label: 'progress-radius',
      type: 'range', value: 20, min: 0, max: 33
    },
    {
      cssVar: ['progress-color'], // alias for the CSS variable
      label: 'progress-color',
      type: 'color',
      value: '#EEEEEE'
    },
    {
      cssVar: ['fill-color'], // alias for the CSS variable
      label: 'fill-color',
      type: 'color',
      value: '#0366D6'
    },
    "Ticks",
    {
      cssVar: ['show-min-max'],
      label: 'hide min/max',
      type: 'checkbox',
      value: 'none'
    },
    {
      cssVar: ['ticks-thickness', 'px'],
      label: 'ticks-thickness',
      type: 'range',
      value: 1, min: 0, max: 10
    },
    {
      cssVar: ['ticks-height', 'px'],
      label: 'ticks-height',
      type: 'range',
      value: 5, min: 0, max: 15
    },
    {
      cssVar: ['ticks-gap', 'px'],
      label: 'ticks-gap',
      type: 'range',
      value: 5, min: 0, max: 15
    },
    {
      cssVar: ['min-max-x-offset', '%'],
      label: 'min-max-x-offset',
      type: 'range',
      value: 10, step: 1, min: 0, max: 100
    },
    {
      cssVar: ['min-max-opacity'],
      label: 'min-max-opacity',
      type: 'range', value: .5, step: .1, min: 0, max: 1
    },
    {
      cssVar: ['ticks-color'], // alias for the CSS variable
      label: 'ticks-color',
      type: 'color',
      value: '#AAAAAA'
    },
  ]
}

def_of_all_opt=[];


function add_all_chs_pln(arr_data){

str_of_app="<form action='../payment/?src_pay=ent' method='POST' style='display: contents;'>";
def_of_all_opt=arr_data;




for (var i = 0; i < 8; i++) {
   data_of_loc= arr_data[i]



if(data_of_loc['mult_oth_fact']==undefined){

prc_of_pln=(data_of_loc['value_con']*data_of_loc['con_mult_fact']);

}else{

prc_of_pln=(data_of_loc['value_con']*data_of_loc['con_mult_fact'])*arr_data[data_of_loc['mult_oth_fact']]['value_con'];


}


str_of_app+='<div class="pln-sel-of-dt col-lg-8 col-md-8 col-sm-12 col-xs-12" style=" "> <div class="email-txt-sel-dt-avl"> <div class="head-of-sld-txt">'+data_of_loc['name']+'</div> <div class="sldr-con"> <div class="range-slider" style="--min:'+data_of_loc['low_limit']+'; --max:'+data_of_loc['upp_limit']+'; --value:'+data_of_loc['value_con']+'; --text-value:&quot;'+data_of_loc['value_con']+'&quot;; --suffix:&quot; '+data_of_loc['text_hov']+'&quot;; width: 100%;"> <input class="chg_sld_pln" id_of_ele="'+i+'" name="'+i+'"  id="'+data_of_loc['id']+'" type="range" min="'+data_of_loc['low_limit']+'" max="'+data_of_loc['upp_limit']+'" value="'+data_of_loc['value_con']+'" oninput="this.parentNode.style.setProperty(\'--value\',this.value); this.parentNode.style.setProperty(\'--text-value\', JSON.stringify(this.value))"> <output></output> <div class="range-slider__progress"></div> </div> </div> </div> <div class="other-con-of-cst"> <span class="cst-of-pln">$<span id="tot-prc-of-pln-'+data_of_loc['id']+'" class="sel_pln_con">'+prc_of_pln+'</span><br><span class="txt-of-cst-res">For Selected '+data_of_loc['text_hov']+'</span> </div> </div>';

};


str_of_app+='<div class="tot-of-pln-cst"> <div class="pln-sel-of-dt col-lg-8 col-md-8 col-sm-12 col-xs-12" style="background: #611f69;"> <div class="email-txt-sel-dt-avl" style=" padding: 19px; text-align: center; "> <div class="plan-cst-lst-tot-con" >$<span id="tot-of-pln-chg">40</span></div> <span class="txt-of-cst-res" style=" color: #b9b5b5; ">For Selected Contact</span> </div> <div class="other-con-of-cst tot-dsg-for-mob" style=" padding: 37px; "> <button type="submit" class="c-button v--left v--primary" style=" padding: 10px; background: white; color: #611f69; ">Go To Pay</button> </div> </div> </div> </form>';

$(".all-pln-con").append(str_of_app);





total_of_all_pln_sel();

}


function total_of_all_pln_sel(){

add_pln=0;


$('.sel_pln_con').map(function() {



    add_pln=add_pln+parseFloat($(this).text());

});

$("#tot-of-pln-chg").html(Math.round((add_pln + Number.EPSILON) * 100) / 100);

}



$(document).on('change','.chg_sld_pln',function(){

qun_of_sel=$(this).val();
id=$(this).attr('id');

id_of_ele_crt=$(this).attr('id_of_ele');

chg_prc_spn="tot-prc-of-pln-"+id;

console.log(id_of_ele_crt);

data_of_loc=def_of_all_opt[id_of_ele_crt];

if(data_of_loc['mult_oth_fact']==undefined){

prc_of_pln=(qun_of_sel*data_of_loc['con_mult_fact']);

}else{



prc_of_pln=(qun_of_sel*data_of_loc['con_mult_fact'])*parseInt($("#"+def_of_all_opt[def_of_all_opt[id_of_ele_crt]['mult_oth_fact']]['id']).val());


}



$("#"+chg_prc_spn).html(Math.round((prc_of_pln + Number.EPSILON) * 100) / 100);



total_of_all_pln_sel();

})


function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      
      add_all_chs_pln(JSON.parse(this.responseText));
    }
  };
  xhttp.open("GET", "data_of_pln.json", true);
  xhttp.send();
}

loadDoc();


</script>