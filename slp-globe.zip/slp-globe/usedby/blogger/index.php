<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>
</head>

<link rel="stylesheet" type="text/css" href="../../css/main.css">

<style type="text/css">


body{
	font-family: 'IBM Plex Sans', sans-serif !important;
letter-spacing:0.2px;
}



a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.c-nav--primary {
    padding: 0;
    height: 10vh;
    background-color: #fff;
    border-bottom: 1px solid #ebeaeb;
    z-index: 1000;
    top: 0;
    position: fixed;

  }
.c-slacklogo{
	width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
	font-weight: 400;
}

.main-conetent{
	margin-top: 10vh;

  }

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}
.container{
	margin: 0px;
	width: 100%;
padding: 0px;
}

.row{
	margin: 0px;
}
.rw-mini-con{
	padding: 100px 80px;
}

.col-txt-of-rw{
	padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

	background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;
    text-align: left;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }

    .txt_alg_cnt{
        text-align: center;
    }


    .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

    .col_height_300{
        min-height: 350px;
    }








    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
}




.rw-mini-con {
    padding: 100px 80px;
   
    overflow: scroll;
  }
  

  .div-dsgn {
    text-align: center;
    margin: 20px 0px;
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1612195541/landing/Horiz-line_tgfmhw.jpg);
    background-size: contain;
  }
  .div-txt-con.c-billboard__kicker.c-billboard__kicker__text.u-text--uppercase {
    text-align: center;
    color: white;
    background: #4a154b;
    padding: 10px;
    border-radius: 1000px;
  }


  li.fet-btn-li {
    list-style: none;
    padding: 10px;
    font-size: 15px;
    font-weight: 600;
    font-family: 'Lato', sans-serif;
    border: 2px solid #611f69;
    border-radius: 10px;
    margin-top: 10px;
  }

  ul.ul-lst-of-fet {
    width: 300px;
    border-radius: 10px;
    
  }

  .fet-btn-li-act{
    background: #611f69;
    color: white;
  }

  .main-mac-scr {
    border-radius: 10px;
    background: #2b092b;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
    border-right: none !important;
  }
  .rw-mini-con {
    padding: 80px 0px;
    overflow: scroll;
  }
  
  li.li-fr-side-nav {
    list-style: none;
    padding: 10px;
  }
  .main-bod-con {
    width: 88%;
    height: 300px;
    background: white;
  }

  .main-bod-con {
    width: 88%;
    background: white;
    padding: 50px;
  }
  


  .crd-for-con {
    width: 40%;
    background: #f2f2f2;
    border-radius: 10px;
    padding: 10px;
    display: inline-block;
    margin-right: 9%;
}
  .crd-con-txt {
    min-width: 100%;
    height: auto;
    padding: 20px;
    color: #2b092b;
    font-family: 'Lato', sans-serif;
    }

    .only-rw-fl {
    min-width: 100%;
    height: 10px;
    margin: 10px 0px;
    background: #d8c9cc;
    border-radius: 10px;
  }

  img.img-ico-fet-cld {
    height: 50px;

}

  .main-mac-scr{
    display: none;
  }

  .menu-head-mac-scr {
    padding: 10px;
    width: 100%;
    background: #f2f2f2;
}

ul.men-dt-crd {
    width: auto;
    background: #f2f2f2;
    width: fit-content;
    margin: auto;
    padding: 7px;
    border-radius: 10px;
    margin-top: 10px;
    text-align: left;
    }
    li.men-of-li {
    list-style: none;
    font-size: 10px;
    text-transform: uppercase;
    padding: 5px;
    font-weight: 500;
}

span.bdg-men-dt {
    padding: 5px;
    background: #777373;
    color: white;
    font-size: 10px;
    border-radius: 10px;
    font-weight: 500;
    text-transform: uppercase;

    }

    .temp-fet-lib-ico {
    width: 20%;
    height: 100px;
    background: #f2f2f2;
    border-radius: 10px;
    margin-top: 10px;
    margin-bottom: 10px;
    display: inline-flex;
    margin-right: 10px;

}

.edt-div-in-temp-fet {
    height: 100%;
    width: 59%;
    display: inline-block;

    }

    .std-div-in-temp-fet {
    height: 100%;
    width: 40%;
    display: inline-block;
    background: #f2f2f2;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 20px;
}

.btn-rect {
    height: 20px;
    width: 40px;
    background: #949090;
    border-radius: 10px;
    }
    .con-of-img-thumb {
    height: 100%;
    overflow: hidden;
}

.sml-obj-rect-height{
    width: 50px !important;
    height: 60px !important;
    background: #dcd5d5;

}

.ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
    }
    .ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
}


.pro-det-dis {
    width: 60%;
    height: 100%;
    display: inline-block;
    padding: 40px;
    }

    .pro-ico-dis {
    width: 60;
    height: 60;
    border-radius: 50%;
    background: #8c8585;
}

.pro-ana-dis-bx {
    height: 100%;
    width: 39%;
    display: inline-block;
    padding: 40px;
    }

    .ana-list-dis {
    width: 100%;
    height: 100%;
    background: #f2f2f2;
    border-radius: 10px;
}

p.abt-para-cls {
    font-size: 20px;
    padding-top: 100px;
    font-weight: 600;

    }

    .fet-def-fully {
    padding-top: 40px;
}

li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'Lato' !important;
    font-size: 15px;
}

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.rw-mini-con.row.flex-ele-sec-scr {
    background-size: cover;
    background-repeat: no-repeat !important;
    background-size: cover !important;

    }
    
</style>

<body>



<?php

require("../../php/header.php");


?>



<div class="main-conetent">



<div class="rw-mini-con row flex-ele-sec-scr" style="
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1613368473/landing/38943631-flat-wallpapers_sitvet.jpg);
    background-color: #4a154b;
    background-position: top;
    background-repeat: repeat-y;
    background-size: 100%;
">
    <div class="col-txt-of-rw" style="
    text-align: center;
">
      <div class="c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
    text-align: center;
    color: white;
">Blogger</div>
      <h2 class="tag_ln_mn" style="
    color: white;
    text-align:center;
">Sycista Plateform For Blogger</h2>
      <p class="txt-para-dt" style="
    color: white;
    margin: auto;
    font-size: 13px;
    text-align:center;
">It's easy to create campign for blogger.</p>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Browse Guide</a>
</div>

    </div>
    
  </div>







<div class="rw-mini-con row flex-ele-sec-scr">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Easy</span></div>
      <h2 class="tag_ln_mn" style="
    font-size: 60px;
    font-weight: 900;
">Easy to uild campign for blogger after adding Site.</h2>
      
<div class="fet-def-fully">

<ul>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Easy to Add site.</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Verify after simply Code integration.</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Give permission To crawl.</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Only select url and send.</li>

</ul>


</div>


    </div>
    <div class="col-sm-6" style="padding: 0px;">


<img src="https://res.cloudinary.com/heptera/image/upload/v1613369604/landing/danist-8Gg2Ne_uTcM-unsplash_frrhgv.jpg">




















      
    </div>
  </div>







<div class="rw-mini-con row ">
    




 <div class="col-sm-6" style="padding: 0px;">


<img src="https://res.cloudinary.com/heptera/image/upload/v1613369663/landing/rodion-kutsaev-VKfqHv7qjNs-unsplash_fxvfee.jpg">




















      
    </div>



    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">visual</span></div>
      <h2 class="tag_ln_mn" style="
    font-size: 60px;
    font-weight: 900;
">Template editor with well design analysis dashboard.</h2>
      
<div class="fet-def-fully">

<ul>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Without stress to build template.</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Easy to use Tempate Editor</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Analysis Dashboard To view Report.</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Segment According to analysis report.</li>

</ul>


</div>


    </div>
   
  </div>








<div class="rw-mini-con row flex-ele-sec-scr">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Devide And Use</span></div>
      <h2 class="tag_ln_mn" style="
    font-size: 60px;
    font-weight: 900;
">Segment Your Audiance According Your data and Plateform AI.</h2>
      
<div class="fet-def-fully">

<ul>


    <li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Know Interest Of your audiance</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Reduced cost of campign.</li>

<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Segment Data According table values</li>
<li class="li-ele-fet-def"><i class="fas fa-check-circle"></i>Sycista gives Predicted demographic.</li>

</ul>


</div>


    </div>
    <div class="col-sm-6" style="padding: 0px;">


<img src="https://res.cloudinary.com/heptera/image/upload/v1613369736/landing/malena-gonzalez-serena-UgmrwjKMhJM-unsplash_te36gq.jpg">




















      
    </div>
  </div>








<div class="rw-mini-con row">



    <div class="col-sm-6" style="padding: 0px;">


<img src="https://res.cloudinary.com/heptera/image/upload/v1613022582/landing/nathan-dumlao-Ofibd6L7uCQ-unsplash_b78sfv.jpg">




















      
    </div>
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Next Step</span></div>
      <h2 class="tag_ln_mn" style="
    font-size: 60px;
    font-weight: 900;
">We Build Powerfull Software But Still We Not Sitting on bench.</h2>
      
<p class='abt-para-cls'>Today We Provide Best Tool for email marketing and automation with analysis report but we will developed plateform for Email CRM.we buld traditional thind in new way.</p>      


<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Explore Our New Idea</a>

    </div>
    
  </div>











<?php

require("../../php/sign_up_footer.php");

?>




</div>

<?php require("../../php/footer.php");?>
















</body>
</html>



<script type="text/javascript">


function rem_all_sld_tp(tp_sld){


$("."+tp_sld).map(function() {

$(this).css('display','none');
 

});


}



function add_trg_act(tp_sld){


$("."+tp_sld).map(function() {

$(this).removeClass("fet-btn-li-act");
 

});


}

$(document).on('click','.fet-btn-li',function(){


rem_all_sld_tp($(this).attr("data-con-tp")+"-sld");


add_trg_act($(this).attr("data-con-tp")+"-sld-trg");

$(this).addClass("fet-btn-li-act");
con_sld=$(this).attr('data-trg-con')+"-sld";

$('#'+con_sld).toggle('slide', { direction: 'right'}, 500);

})


</script>