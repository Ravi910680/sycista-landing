<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>
</head>

<link rel="stylesheet" type="text/css" href="../css/main.css">

<style type="text/css">


body{
	font-family: 'IBM Plex Sans', sans-serif !important;
letter-spacing:0.2px;
}



a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}


.c-nav--primary {
    padding: 0;
    height: 10vh;
    background-color: #fff;
    border-bottom: 1px solid #ebeaeb;
    z-index: 1000;
    top: 0;
    position: fixed;

  }
.c-slacklogo{
	width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
	font-weight: 400;
}

.main-conetent{
	margin-top: 10vh;

  }

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}
.container{
	margin: 0px;
	width: 100%;
padding: 0px;
}

.row{
	margin: 0px;
}
.rw-mini-con{
	padding: 100px 80px;
}

.col-txt-of-rw{
	padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

	background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }

    .txt_alg_cnt{
        text-align: center;
    }


    .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

    .col_height_300{
        min-height: 350px;
    }








    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
}




.rw-mini-con {
    padding: 100px 80px;
   
    overflow: scroll;
  }
  

  .div-dsgn {
    text-align: center;
    margin: 20px 0px;
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1612195541/landing/Horiz-line_tgfmhw.jpg);
    background-size: contain;
  }
  .div-txt-con.c-billboard__kicker.c-billboard__kicker__text.u-text--uppercase {
    text-align: center;
    color: white;
    background: #4a154b;
    padding: 10px;
    border-radius: 1000px;
  }


  li.fet-btn-li {
    list-style: none;
    padding: 10px;
    font-size: 15px;
    font-weight: 600;
    font-family: 'Lato', sans-serif;
    border: 2px solid #611f69;
    border-radius: 10px;
    margin-top: 10px;
  }

  ul.ul-lst-of-fet {
    width: 300px;
    border-radius: 10px;
    
  }

  .fet-btn-li-act{
    background: #611f69;
    color: white;
  }

  .main-mac-scr {
    border-radius: 10px;
    background: #2b092b;
    border-top-right-radius: 0px;
    border-bottom-right-radius: 0px;
    border-right: none !important;
  }
  .rw-mini-con {
    padding: 80px 0px;
    overflow: scroll;
  }
  
  li.li-fr-side-nav {
    list-style: none;
    padding: 10px;
  }
  .main-bod-con {
    width: 88%;
    height: 300px;
    background: white;
  }

  .main-bod-con {
    width: 88%;
    background: white;
    padding: 50px;
  }
  


  .crd-for-con {
    width: 40%;
    background: #f2f2f2;
    border-radius: 10px;
    padding: 10px;
    display: inline-block;
    margin-right: 9%;
}
  .crd-con-txt {
    min-width: 100%;
    height: auto;
    padding: 20px;
    color: #2b092b;
    font-family: 'Lato', sans-serif;
    }

    .only-rw-fl {
    min-width: 100%;
    height: 10px;
    margin: 10px 0px;
    background: #d8c9cc;
    border-radius: 10px;
  }

  img.img-ico-fet-cld {
    height: 50px;

}

  .main-mac-scr{
    display: none;
  }

  .menu-head-mac-scr {
    padding: 10px;
    width: 100%;
    background: #f2f2f2;
}

ul.men-dt-crd {
    width: auto;
    background: #f2f2f2;
    width: fit-content;
    margin: auto;
    padding: 7px;
    border-radius: 10px;
    margin-top: 10px;
    text-align: left;
    }
    li.men-of-li {
    list-style: none;
    font-size: 10px;
    text-transform: uppercase;
    padding: 5px;
    font-weight: 500;
}

span.bdg-men-dt {
    padding: 5px;
    background: #777373;
    color: white;
    font-size: 10px;
    border-radius: 10px;
    font-weight: 500;
    text-transform: uppercase;

    }

    .temp-fet-lib-ico {
    width: 20%;
    height: 100px;
    background: #f2f2f2;
    border-radius: 10px;
    margin-top: 10px;
    margin-bottom: 10px;
    display: inline-flex;
    margin-right: 10px;

}

.edt-div-in-temp-fet {
    height: 100%;
    width: 59%;
    display: inline-block;

    }

    .std-div-in-temp-fet {
    height: 100%;
    width: 40%;
    display: inline-block;
    background: #f2f2f2;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    padding: 20px;
}

.btn-rect {
    height: 20px;
    width: 40px;
    background: #949090;
    border-radius: 10px;
    }
    .con-of-img-thumb {
    height: 100%;
    overflow: hidden;
}

.sml-obj-rect-height{
    width: 50px !important;
    height: 60px !important;
    background: #dcd5d5;

}

.ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
    }
    .ana-grph-hand {
    height: 150px;
    width: 44%;
    background: #f2f2f2;
    display: inline-block;
    border-radius: 10px;
}


.pro-det-dis {
    width: 60%;
    height: 100%;
    display: inline-block;
    padding: 40px;
    }

    .pro-ico-dis {
    width: 60;
    height: 60;
    border-radius: 50%;
    background: #8c8585;
}

.pro-ana-dis-bx {
    height: 100%;
    width: 39%;
    display: inline-block;
    padding: 40px;
    }

    .ana-list-dis {
    width: 100%;
    height: 100%;
    background: #f2f2f2;
    border-radius: 10px;
}
</style>

<body>



<?php

require("../php/header.php");


?>



<div class="main-conetent">



<div class="rw-mini-con row flex-ele-sec-scr" style="
    background-image: url(https://res.cloudinary.com/heptera/image/upload/v1612193834/landing/image_1_o02ohn.png);
    background-color: #4a154b;
    background-position: top;
    background-repeat: repeat-y;
    background-size: 100%;
">
    <div class="col-txt-of-rw" style="
    text-align: center;
">
      <div class="c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
    text-align: center;
    color: white;
">Marketing Plateform</div>
      <h2 class="tag_ln_mn" style="
    color: white;
">Made Profit Using silent Way</h2>
      <p class="txt-para-dt" style="
    color: white;
    margin: auto;
    font-size: 13px;
">Powerfull App For drag your bussiness on TOP In real field.</p>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    
  </div>



<div class="div-dsgn"><div id="" class="div-txt-con c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
">List managment</div></div>


<div class="rw-mini-con row">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">manage list</span></div>
      <h2 class="tag_ln_mn">Get Your Whole Contact At One place.</h2>
      <h4 class="" style="
    font-family: 'Lato', sans-serif;
    font-size: 20px;
">See How To manage List :</h4>
      <div class='fet-ext'>
        <ul class="ul-lst-of-fet">

          <li class="fet-btn-li fet-btn-li-act contact-sld-trg"  data-trg-con="crt-lst" data-con-tp="contact">Create List </li>
          <li class="fet-btn-li contact-sld-trg" style="border-top: 2px solid #611f69;border-bottom: 2px solid #611f69;" data-trg-con="add-con" data-con-tp="contact">Add Contact</li>
          <li class="fet-btn-li contact-sld-trg" data-trg-con="mng-con" data-con-tp="contact">Manage Contact</li>

        </ul>


      </div>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6" style="padding: 0px;">


<div class="main-mac-scr contact-sld" id="crt-lst-sld" style="
    border: 1px solid #611f69;display:block;
">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con">


    <div class="con-crt-lst">
    
        <div class="crd-for-con">
        
    
    <div class="crd-con-txt">Using dashboard</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
">How to use</a>
    
        </div>
    
        <div class="crd-for-con">
    


<div class="crd-con-txt">Using API Request</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
">Documentation</a>
    


        </div>
    
    </div>
    
    

</div>


</div>


</div>

















<div class="main-mac-scr contact-sld" id="add-con-sld" style="background: white; border: none;">
    
    
    
    




<div class="con-crt-lst">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/984/984145.svg?token=exp=1612330604~hmac=0f92fd5bd651996953a2b898b54e7eda" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Connect now</a>
    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2111/2111381.svg?token=exp=1612330218~hmac=a437fdb4b46a3d917639d23ad9ddace6" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Connect now</a>
    
        </div>
    
    </div><div class="con-crt-lst" style="
    margin-top: 9%;
">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/720/720236.svg?token=exp=1612330327~hmac=30785d4f1ea664b6d985ecee07496b57" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Connect now</a>
    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/3143/3143529.svg?token=exp=1612330422~hmac=38f05889a07eaa91ed646a70adb06aec" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Add Contact</a>
    
        </div>
    
    </div>


</div>








<div class="main-mac-scr contact-sld" id="mng-con-sld" style="
    border: 1px solid #611f69;

">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
">
    <div class="menu-head-mac-scr">

    <span class="bdg-men-dt">Segment</span>
    <span class="bdg-men-dt">Tags</span>
    <span class="bdg-men-dt">analysis</span>
<span class="bdg-men-dt">Custom Field</span>
<span class="bdg-men-dt">Add Contact</span>

</div>

<div class="menu-opn-mc-itr">

    <ul class="men-dt-crd">
    
        
<li class="men-of-li">Add contact</li>
<li class="men-of-li">Change tag</li>
<li class="men-of-li">chnage status</li>
<li class="men-of-li">Unsubscribe</li><li class="men-of-li">archived contact</li>
    </ul>

</div>

    
    
    
</div>


</div>


</div>

      
    </div>
  </div>





  <div class="div-dsgn"><div id="" class="div-txt-con c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
">Template</div></div>
















































<div class="rw-mini-con row">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Template</span></div>
      <h2 class="tag_ln_mn">Personlize Content Make Efficient Interection.</h2>
      <h4 class="" style="
    font-family: 'Lato', sans-serif;
    font-size: 20px;
">See How To Use Template :</h4>
      <div class='fet-ext'>
        <ul class="ul-lst-of-fet">

          <li class="fet-btn-li fet-btn-li-act template-sld-trg"  data-trg-con="temp-lib" data-con-tp="template">Template library</li>
          <li class="fet-btn-li template-sld-trg"  data-trg-con="temp-respo" data-con-tp="template">Responsive Template</li>
          <li class="fet-btn-li template-sld-trg" data-trg-con="med-man" data-con-tp="template">Media Managment</li>

          <li class="fet-btn-li template-sld-trg" data-trg-con="api-temp" data-con-tp="template">API Template</li>

        </ul>


      </div>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6" style="padding: 0px;">


<div class="main-mac-scr template-sld" id="temp-lib-sld" style="
    border: 1px solid #611f69;display:block;
">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>


<div class="main-bod-con" style="
    padding: 0px;
">


    <div class="con-crt-lst" style="height: 100%;overflow: hidden;">
    
        


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>

<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>

<div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div><div class="temp-fet-lib-ico">

    <div class="img-lib-temp-con"></div>
    
    

</div>
    
        
    
    </div>
    
    

</div>


</div>


</div>

















<div class="main-mac-scr template-sld" id="temp-respo-sld" style="background: white; border: none;">
    
    
    <img src="https://cdn.dribbble.com/users/1931558/screenshots/6471342/rsponsive1.gif" style="max-width: 700px;width: 100%;">
    
    

</div>






<div class="main-mac-scr template-sld" id="med-man-sld" style="">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
">

<div class="edt-div-in-temp-fet" style="
">


    <div class="temp-fet-lib-ico" style="
    display: block;
    margin: 25%;
    background-image: url(https://www.flaticon.com/svg/vstatic/svg/636/636045.svg?token=exp=1612430605~hmac=5f18c25eb67ccd7bb8382860d671a108);
    background-repeat: no-repeat;
    background-size: 20px;
">

    <div class="img-lib-temp-con"></div>
    
    

</div>
    
    


</div>
    <div class="std-div-in-temp-fet">

    <div class="btn-rect"></div>
    <div class="con-of-img-thumb">
    
    
        


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>

<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>


<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div>

<div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    

</div><div class="temp-fet-lib-ico sml-obj-rect-height">

    <div class="img-lib-temp-con"></div>
    
    
      
    
    </div>
    
    
    
    </div>

</div>
    
    

</div>


</div>


</div>













      
    </div>
  </div>



















































  <div class="div-dsgn"><div id="" class="div-txt-con c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
">Studio</div></div>





















<div class="rw-mini-con row">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Media</span></div>
      <h2 class="tag_ln_mn">Place That Make Your Media More Powerfull.</h2>
      <h4 class="" style="
    font-family: 'Lato', sans-serif;
    font-size: 20px;
">See How To Manage Media :</h4>
      <div class='fet-ext'>
        <ul class="ul-lst-of-fet">

          <li class="fet-btn-li fet-btn-li-act studio-sld-trg"  data-trg-con="dir-man" data-con-tp="studio">Directory Managment</li>
          <li class="fet-btn-li studio-sld-trg" data-trg-con="up-way" data-con-tp="studio">Upload Way</li>
          <li class="fet-btn-li studio-sld-trg" data-trg-con="sup-med" data-con-tp="studio">Supported Media</li>
          <li class="fet-btn-li studio-sld-trg" data-trg-con="pow-cdn" data-con-tp="studio">Powerfull CDN</li>

        </ul>


      </div>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6" style="padding: 0px;">


<div class="main-mac-scr studio-sld" id="dir-man-sld" style="
    border: 1px solid #611f69;display:block;
">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con">


    <div class="con-crt-lst">
    
        <div class="crd-for-con">
        
    
    <div class="crd-con-txt">Using dashboard</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
">How to use</a>
    
        </div>
    
        <div class="crd-for-con">
    


<div class="crd-con-txt">Using API Request</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
">Documentation</a>
    


        </div>
    
    </div>
    
    

</div>


</div>


</div>

















<div class="main-mac-scr studio-sld" id="up-way-sld" style="background: white; border: none;">
    
    
    
    




<div class="con-crt-lst">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/984/984145.svg?token=exp=1612330604~hmac=0f92fd5bd651996953a2b898b54e7eda" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2111/2111381.svg?token=exp=1612330218~hmac=a437fdb4b46a3d917639d23ad9ddace6" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
    </div><div class="con-crt-lst" style="
    margin-top: 9%;
">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/4052/4052974.svg?token=exp=1612455048~hmac=803cfd945662fa0d0076256a5a3a55ee" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/3143/3143529.svg?token=exp=1612330422~hmac=38f05889a07eaa91ed646a70adb06aec" class="img-ico-fet-cld"></div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload Now</a>
    
        </div>
    
    </div>


</div>








<div class="main-mac-scr studio-sld" id="sup-med-sld" style="
    background: white;
    border: none;
    text-align: center;
">














<div class="con-crt-lst">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2306/2306094.svg?token=exp=1612344271~hmac=51c6196da70c40a71df6d69d25278991" class="img-ico-fet-cld"></div>

        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2306/2306156.svg?token=exp=1612344345~hmac=8e13ba7e87fdb90987f70cb89460521b" class="img-ico-fet-cld"></div>

    
        </div>
    
    </div>




<img src="https://image.freepik.com/free-vector/open-folder-folder-with-documents-document-protection-concept_183665-104.jpg" style="
    width: 300px;
"><div class="con-crt-lst" style="
">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2306/2306179.svg?token=exp=1612344373~hmac=857dee54d6f9e3bc1f4db7a15b85561e" class="img-ico-fet-cld"></div>

    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/2306/2306117.svg?token=exp=1612344208~hmac=13366b86beb90a40b872171be4ca9313" class="img-ico-fet-cld"></div>

    
        </div>
    
    </div>





</div>
























<div class="main-mac-scr studio-sld" id="pow-cdn-sld" style="
    

">
  

 <img src="https://res.cloudinary.com/heptera/image/upload/v1612454976/landing/cloud-network-1768666-1504142_qnqoay.png" style="
">
</div>






























      
    </div>
  </div>




































<div class="div-dsgn"><div id="" class="div-txt-con c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
">API</div></div>




<div class="rw-mini-con row">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">API</span></div>
      <h2 class="tag_ln_mn">Develope App like Pro With Our Marketing API.</h2>
      <h4 class="" style="
    font-family: 'Lato', sans-serif;
    font-size: 20px;
">See How To use IT :</h4>
      <div class='fet-ext'>
        <ul class="ul-lst-of-fet">

          <li class="fet-btn-li fet-btn-li-act api-sld-trg"  data-trg-con="send-api" data-con-tp="api">Sending API</li>
          <li class="fet-btn-li api-sld-trg" data-trg-con="man-api" data-con-tp="api">Managment API</li>
          <li class="fet-btn-li api-sld-trg" data-trg-con="api-temp" data-con-tp="api">API Template</li>
          <li class="fet-btn-li api-sld-trg" data-trg-con="send-ana" data-con-tp="api">Sending Analysis</li>

        </ul>


      </div>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6" style="padding: 0px;">


<div class="main-mac-scr api-sld" id="send-api-sld" style="
    border: 1px solid #611f69;display:block;
">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
    overflow: hidden;
">


    <img src="https://res.cloudinary.com/heptera/image/upload/v1599150330/Screen_Shot_1942-06-12_at_9.54.39_PM_usphjv.png" style="
    height: 100%;
    min-width: 100%;
">

</div>

</div>


</div>














<div class="main-mac-scr api-sld" id="man-api-sld" style="background: white; border: none;">
    
    
    
    




<div class="con-crt-lst">
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt" style="font-weight: 700;"><img src="https://www.flaticon.com/svg/vstatic/svg/3979/3979303.svg?token=exp=1612457448~hmac=e657806922b1234099dd73203a41f299" class="img-ico-fet-cld" style="
    padding-right: 5px;
">CREATE FOLDER</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
        <div class="crd-for-con" style="font-weight: 700;">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/685/685686.svg?token=exp=1612457793~hmac=c5dd8abd442ef8f59b1fa983db8b4c86" class="img-ico-fet-cld">UPLOAD IMAGE</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
    </div><div class="con-crt-lst" style="
    margin-top: 9%;
">
    
        <div class="crd-for-con" style="font-weight: 700;">
        
    
    <div class="crd-con-txt"><img src="https://www.flaticon.com/svg/vstatic/svg/3336/3336302.svg?token=exp=1612457880~hmac=80db50353ff92f7edbe07948d9567564" class="img-ico-fet-cld" style="
    padding-right: 10px;
">ADD CONTACT</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload now</a>
    
        </div>
    
        <div class="crd-for-con" style="
">
        
    
    <div class="crd-con-txt" style="font-weight: 700;font-size: 13px;"><img src="https://www.flaticon.com/svg/vstatic/svg/1070/1070173.svg?token=exp=1612458173~hmac=9db724b463b8dabb96af18f72399b268" class="img-ico-fet-cld" style="padding-right: 10px;">MANAGE</div>

<div class="only-rw-fl"></div>
<div class="only-rw-fl"></div>
<div class="only-rw-fl" style="
    min-width: 30%;
    width: 30%;
"></div>


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    padding: 5px;
    font-size: 10px;
    width: 100%;
">Upload Now</a>
    
        </div>
    
    </div>


</div>











<div class="main-mac-scr api-sld" id="api-temp-sld" style="
    

">
  

 <img src="https://www.omnisend.com/blog/wp-content/uploads/2020/01/gif-email-featured.gif" style="
">
</div>









<div class="main-mac-scr api-sld" id="send-ana-sld" style="
    background: white;
    border: none;
    text-align: center;
">








<img src="https://magazine.xpert.tv/wp-content/uploads/2020/07/data-analysis.gif" style="
">



</div>




















































      
    </div>
  </div>







<div class="div-dsgn"><div id="" class="div-txt-con c-billboard__kicker c-billboard__kicker__text u-text--uppercase" style="
">Analysis</div></div>




<div class="rw-mini-con row">
    
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">API</span></div>
      <h2 class="tag_ln_mn">Analyze Full List With Personal Profile Responses.</h2>
      <h4 class="" style="
    font-family: 'Lato', sans-serif;
    font-size: 20px;
">See How To use IT :</h4>
      <div class='fet-ext'>
        <ul class="ul-lst-of-fet">

          <li class="fet-btn-li fet-btn-li-act analysis-sld-trg"  data-trg-con="list-ana" data-con-tp="analysis">List Analysis</li>
          <li class="fet-btn-li analysis-sld-trg" data-trg-con="pro-ana" data-con-tp="analysis">Profile Analysis</li>
          
        </ul>


      </div>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6" style="padding: 0px;">


<div class="main-mac-scr analysis-sld" id="list-ana-sld" style="
    border: 1px solid #611f69;display:block;
">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
    width: 100%;
">

    <div class="body-ana-dis">
    
        <div class="head-ana-dis" style="
    text-align: left;
    padding: 20px;
">
        
            <div class="btn-rect" style="
    display: inline-block;
"></div>
            
            <div class="btn-rect" style="
    display: inline-block;
"></div>
            
            <div class="btn-rect" style="
    display: inline-block;
    float: right;
"></div>
        
        </div>
    
        
        <div class="body-ana-dis" style="
    padding: 20px;
">
        
    
    <div class="ana-grph-hand" style="
    margin-right: 10%;
"></div>
    
     <div class="ana-grph-hand"></div>
    
    
        
        </div>
    
    </div>
    
    
    

</div>

</div>


</div>
























<div class="main-mac-scr analysis-sld" id="pro-ana-sld" style="border: 1px solid rgb(97, 31, 105); ">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
    overflow: hidden;
    width: 100%;
">


    <div class="main-bod-con" style="
    padding: 0px;
    width: 100%;
">

    <div class="pro-ana-dis">

    <div class="pro-det-dis">
    
        <div class="pro-ico-dis">
        
        
        </div>

<div class="only-rw-fl"></div>

<div class="only-rw-fl"></div>

<div class="only-rw-fl" style="
    max-width: 30%;
    min-width: 30%;
"></div>
    
    </div>
    
    <div class="pro-ana-dis-bx">
        
        
    
        <div class="ana-list-dis"></div>
    
        
    
    </div>


</div>
    
    
    

</div>

</div>

</div>


</div>













































      
    </div>
  </div>



<?php

require("../php/sign_up_footer.php");

?>




</div>

<?php require("../php/footer.php");?>
















</body>
</html>



<script type="text/javascript">


function rem_all_sld_tp(tp_sld){


$("."+tp_sld).map(function() {

$(this).css('display','none');
 

});


}



function add_trg_act(tp_sld){


$("."+tp_sld).map(function() {

$(this).removeClass("fet-btn-li-act");
 

});


}

$(document).on('click','.fet-btn-li',function(){


rem_all_sld_tp($(this).attr("data-con-tp")+"-sld");


add_trg_act($(this).attr("data-con-tp")+"-sld-trg");

$(this).addClass("fet-btn-li-act");
con_sld=$(this).attr('data-trg-con')+"-sld";

$('#'+con_sld).toggle('slide', { direction: 'right'}, 500);

})


</script>