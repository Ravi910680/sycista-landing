<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">
</head>

<link rel="stylesheet" type="text/css" href="../../css/main.css">

<style type="text/css">


body{
	font-family: 'IBM Plex Sans', sans-serif !important;
letter-spacing:0.2px;
}



a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}

.c-slacklogo{
	width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
	font-weight: 400;
}

.main-conetent{
	padding-top: 70px;
}

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}
.container{
	margin: 0px;
	width: 100%;
padding: 0px;
}

.row{
	margin: 0px;
}
.rw-mini-con{
	padding: 100px 80px;
}

.col-txt-of-rw{
	padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

	background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }

    .txt_alg_cnt{
        text-align: center;
    }


    .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

    .col_height_300{
        min-height: 350px;
    }








    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
.blob{
    display: none;
}
}






.blob {
  position: absolute;
  top: 0;
  left: 0;
  fill: #023F92;
  width: 50vmax;
  z-index: -1;
  
  transform-origin: 50% 50%;
}

@keyframes move {
  0%   { transform: scale(1)   translate(10px, -30px); }
  38%  { transform: scale(0.8, 1) translate(80vw, 30vh) rotate(160deg); }
  40%  { transform: scale(0.8, 1) translate(80vw, 30vh) rotate(160deg); }
  78%  { transform: scale(1.3) translate(0vw, 50vh) rotate(-20deg); }


</style>

<body>

<?php

require("../../php/header.php");


?>


<div class="main-conetent">

<div class="rw-mini-con row flex-ele-sec-scr">

    <div class="blob">
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200">
  <path fill="#FFD6E8" d="M51.1,-60.5C62.1,-51.6,64.2,-31.6,65.8,-13C67.4,5.6,68.5,22.9,61.6,36.2C54.7,49.5,39.7,58.8,22.4,67.7C5.2,76.5,-14.4,85,-30.2,80.4C-45.9,75.8,-57.8,58,-62.7,40.5C-67.6,23.1,-65.5,6,-64.3,-13.2C-63.2,-32.4,-63.1,-53.7,-52.5,-62.7C-41.9,-71.7,-21,-68.4,-0.5,-67.8C20,-67.3,40,-69.4,51.1,-60.5Z" transform="translate(100 100)"></path>
</svg>
</div>
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">API</span></div>
      <h2 class="tag_ln_mn">Make Your App More Interective.</h2>
      <p class="txt-para-dt">Highly usefull for developer to build more interective app throught a email or social media.</p>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6 txt_alg_cnt" >

<img class="img-con-fet-mr-def" src="https://res.cloudinary.com/heptera/image/upload/v1611895829/landing/api/undraw_Code_review_re_woeb_edemfs.png" width="600">

</div>
  </div>


<div class="thrd-rw rw-mini-con row " >

<div class="col-sm-6 ">

<img class="img-con-fet-mr-def" src="https://res.cloudinary.com/heptera/image/upload/v1611898675/landing/api/undraw_file_manager_j85s_pkizgs.svg" width="400">

</div>


<div class="col-sm-6 col_height_300">

<div class='vert_cent_div_comb'>

<h2 class="tag_ln_mn" style="font-size:30px;line-height:1.3;margin:0px;">Manage Contact</h2>

<p class="txt-para-dt">Developer will get ability to create , delete and update contact and also manage images in sycista studio.</p>

</div>

</div>

</div>




<div class="thrd-rw rw-mini-con row flex-ele-sec-scr" >




<div class="col-sm-6 col_height_300">

<div class='vert_cent_div_comb'>
<h2 class="tag_ln_mn" style="font-size:30px;line-height:1.3;margin:0px;">Send Email</h2>

<p class="txt-para-dt">Send email using sending API token when request sent by developer.</p>

</div>

</div>





<div class="col-sm-6 txt_alg_cnt">

<img class="img-con-fet-mr-def" src="https://res.cloudinary.com/heptera/image/upload/v1611898853/landing/api/undraw_hey_email_liaa_1_fuecqi.svg" width="400">

</div>



</div>
















<div class="thrd-rw rw-mini-con row " >

<div class="col-sm-6 ">

<img class="img-con-fet-mr-def" src="https://res.cloudinary.com/heptera/image/upload/v1611899206/landing/api/undraw_design_tools_42tf_vvdfzs.svg" width="600">

</div>


<div class="col-sm-6 col_height_300">


<div class='vert_cent_div_comb'>

<h2 class="tag_ln_mn" style="font-size:30px;line-height:1.3;margin:0px;">Use Template For API</h2>

<p class="txt-para-dt">Eazy to use template with sycista API. only one click to create template use for API.</p>

</div>

</div>

</div>







</div>











<?php

require("../../php/sign_up_footer.php");

?>




</div>

<?php require("../../php/footer.php");?>


</body>
</html>



<script type="text/javascript">


</script>