# Pure-CSS Parallax Scrolling Effect in Chrome

This repository has the completed HTML and CSS files for the code example in the Pure-CSS Parallax Scrolling Effect in Chrome artilce on DigitalOcean. 
