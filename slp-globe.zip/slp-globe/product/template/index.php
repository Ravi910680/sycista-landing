<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@900&display=swap" rel="stylesheet">

<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">
</head>

<link rel="stylesheet" type="text/css" href="../../css/main.css">

<style type="text/css">


body{
	font-family: 'IBM Plex Sans', sans-serif !important;
letter-spacing:0.2px;
}



a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}

.c-slacklogo{
	width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
	font-weight: 400;
}

.main-conetent{
	padding-top: 70px;
}

.tag_ln_mn{
    font-size: 30px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}
.container{
	margin: 0px;
	width: 100%;
padding: 0px;
}

.row{
	margin: 0px;
}
.rw-mini-con{
	padding: 100px 80px;
}

.col-txt-of-rw{
	padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

	background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
   
    animation-delay: 5s;
    
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: black;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico{
    width: 50px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: #f2f2f259;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    .u-text--uppercase {
    text-transform: uppercase!important;
    color: black;

}


span.mor-fet-hd {
    font-weight: bold;
    color: black;
    font-size: 1.125rem;
    font-family: 'Lato', sans-serif;

    }



 .vert_cent_div_comb{
        margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
    }

     .txt_alg_cnt{
        text-align: center;
    }


    .col_height_300{
        min-height: 350px;
    }
</style>

<body>

<?php

require("../../php/header.php");


?>

<div class="main-conetent">

<div class="rw-mini-con row flex-ele-sec-scr">
    <div class='blob'>


<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
  <path fill="#A7F0BA" d="M47.5,-70.1C60.9,-65.4,70.4,-51,72.4,-36.1C74.3,-21.3,68.7,-6.1,64.1,7.5C59.4,21.1,55.8,33.2,49.7,46.6C43.6,60,34.9,74.8,23,78.2C11.1,81.6,-4.1,73.7,-17.2,66.3C-30.4,59,-41.4,52.2,-53,43.4C-64.6,34.6,-76.6,23.7,-77.4,11.7C-78.2,-0.2,-67.7,-13.2,-59.4,-25.3C-51.1,-37.5,-44.8,-48.8,-35.3,-55.2C-25.8,-61.6,-12.9,-63.2,2.1,-66.5C17.1,-69.8,34.2,-74.8,47.5,-70.1Z" transform="translate(100 100)" />
</svg>

    </div>
    <div class="col-sm-6 col-txt-of-rw">
      <div class="c-billboard__kicker"><span class="c-billboard__kicker__text u-text--uppercase">Template</span></div>
      <h2 class="tag_ln_mn">Beautiful template for marketing.</h2>
      <p class="txt-para-dt">Using Sycista|<sub>editor</sub> Edit email template and used with sending API also send by campigns.</p>

<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary ">Try for free</a>
</div>

    </div>
    <div class="col-sm-6">



<img class="img-con-fet-mr-def" src="https://res.cloudinary.com/heptera/image/upload/v1611900191/landing/api/undraw_wireframing_nxyi_risenh.svg" width="600">


      
    </div>
  </div>


<div class="thrd-rw rw-mini-con row " >

<div class="col-sm-6 ">

<img class="img-con-fet-mr-def" src="https://image.flaticon.com/icons/svg/2923/2923618.svg" width="300">

</div>


<div class="col-sm-6 col_height_300">


<div class='vert_cent_div_comb'>

<h2 class="tag_ln_mn" style="font-size:30px;line-height:1.3;margin:0px;">Create Dynamic</h2>

<p class="txt-para-dt">Dynamic Template makes Your campign more powerful to your branding and it's very easy to make with sycista.</p>

</div>

</div>

</div>




<div class="thrd-rw rw-mini-con row flex-ele-sec-scr" >




<div class="col-sm-6 col_height_300">


<div class='vert_cent_div_comb'>

<h2 class="tag_ln_mn" style="font-size:30px;line-height:1.3;margin:0px;">Send On Your Time</h2>

<p class="txt-para-dt">Send pesonalized  Email template with dynamic field That time you select with API.only with one code without More complexity.</p>

</div>

</div>


<div class="col-sm-6 mac-scr-con-main">

<div class="main-mac-scr" style="background:#f2f2f2;">
    <div class="head-mac-scr">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr">
<img src="https://res.cloudinary.com/heptera/image/upload/v1599150330/Screen_Shot_1942-06-12_at_9.54.39_PM_usphjv.png" style="
    width: 100%;
">

</div>


</div>

</div>



</div>



<div class="sec-fetr-rw">



 <h1 class="tag_ln_mn med_font_sz_head">Make Dynamic Template Without Dificulty.</h1>


<div class="txt-para-dt font-sz-fet-txt con-cent-alg" style='margin:auto;'>Types of template Decrease your workload.</div>
   

<div class="main-con-of-fet">


<div class="mk-btfl row">


   

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
   <i class="fal fa-pager"></i>
    </div>
    <div class="fet-head">
    <span class='mor-fet-hd'>Simple Template</span>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Send template that is use to normal campign.that is set by Sycista app.</div>
   


</div>

    
<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fal fa-code-merge"></i>
    </div>
    <div class="fet-head">
    <span class='mor-fet-hd'>API Template</span>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">That used for send with API with only unoque template code. it is also have normal dynamic and advance unique option.</sub></div>
   


</div>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
   <i class="fal fa-blog"></i>
    </div>
    <div class="fet-head">
   <span class='mor-fet-hd'>Blog Template<sup>BETA</sup></span>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Blog template used for send your blog post that have looped content like more post without set in app or API.</div>
   


</div>

</div>

</div>


















</div>







<?php

require("../../php/sign_up_footer.php");

?>




</div>

<?php require("../../php/footer.php");?>


</body>
</html>



<script type="text/javascript">


</script>