
<div class="rw-mini-con row">
    <div class="col-sm-4 col-txt-of-rw">
      
     <img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="50">

    </div>
    <div class="col-sm-8" >

<div class='col-foot-nav col-sm-3'>

<p class='txt-para-dt txt-tran-cap'>Product</p>


<ul>
<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/template/">

Template
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/survey/">

Survey
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/studio/">

Studio
</a>

</li>


<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/social/">

Social Media
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/analysis/">

Analysis
</a>

</li>


<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/product/api/">

API
</a>

</li>

</ul>

</div>
<div class='col-foot-nav col-sm-3'>




<p class='txt-para-dt txt-tran-cap'>Used by </p>


<ul>
<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/startup/">

Startups
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/blogger/">

Blogger
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/enterprise/">

Enterprise

</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/marketer/">

Marketer
</a>

</li>


<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/ecommerce/">

Ecommerce
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/usedby/developer/">

Developer
</a>

</li>

</ul>

</div>
<div class='col-foot-nav col-sm-3'>




<p class='txt-para-dt txt-tran-cap'>Resource</p>


<ul>
<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="">

Guide
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="">

Blog
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="">

Video

</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="">

Documentation
</a>

</li>


<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="">

Knowledge Base</a>

</li>



</ul>


</div>
<div class='col-foot-nav col-sm-3'>





<p class='txt-para-dt txt-tran-cap'>Company</p>


<ul>
<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/company/about/">

About
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/company/contact/">

Contact
</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/company/team/">

Team

</a>

</li>

<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/company/career/">

Career
</a>

</li>


<li class='li-ele-fet-def lst-foot-nav'>
<a class='hrf-foot-nav' href="https://<?php echo $url_main;?>/company/trust/">

Trust
</a>

</li>



</ul>



</div>

      
    </div>
  </div>







<div class="foot-plcy-pad" style="background:#f5f5f5;">

<div class="col-sm-6">

<ul style="
    margin-bottom: 0px;
">
<li class="li-ele-fet-def ls-pol-bot"><a class='hrf-foot-nav' href="">Privacy</a></li>
<li class="li-ele-fet-def ls-pol-bot"><a class='hrf-foot-nav' href="">Terms</a></li>
<li class="li-ele-fet-def ls-pol-bot"><a class='hrf-foot-nav' href="">Status</a></li>

</ul>


</div>


<div class="col-sm-6 soc-med-ico_hld">

<ul style="
    margin-bottom: 0px;
">
<li class="li-ele-fet-def ls-pol-bot soc_med_ico"><a class='hrf-foot-nav' href=""><i class="fab fa-facebook-square"></i></a></li>
<li class="li-ele-fet-def ls-pol-bot soc_med_ico"><a class='hrf-foot-nav' href=""><i class="fab fa-twitter-square"></i></a></li>
<li class="li-ele-fet-def ls-pol-bot soc_med_ico"><a class='hrf-foot-nav' href=""><i class="fab fa-youtube-square"></i></a></li>

</ul>



</div>

</div>

<div class="copy-cont"><span class='copy-txt'> Copyright 2020 Sycista|<sub>mail</sub> is copytited by Sycista Inc. Other Trademark copyright by respected owner.</span></div>

