
<div class="rw-mini-con background-clr" style="
    background: #611f69;
    text-align: center;
">
    <div class="col-txt-of-rw">
      
      <h2 class="tag_ln_mn tag_bottom_mob" style="
    color: white;
">Make Campign More Powerfull.</h2>
     
<div class="pad-top">
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--secondary v--no-border ">Try for free</a>
</div>

    </div>
    
  </div>
