
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">




<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css">


<style type="text/css">






.blob {
  position: absolute;
  top: 0;
  left: 0;
  fill: #023F92;
  width: 50vmax;
  z-index: -1;
  
  transform-origin: 50% 50%;
}



    address, ol, p, ul{
        font-family: 'lato';
    }
    

    
    @media only screen and (max-width: 480px) {
  .flex-ele-sec-scr {
    display: flex;
    flex-direction: column-reverse;
  }

  .col-sm-6{
text-align: center;
    padding: 20px 0px;

  }

  .rw-mini-con {
    padding: 50px 20px;

}
p.txt-para-dt {
    text-align: left;
    }

    h2.tag_ln_mn {
    text-align: left;

}
.img-con-fet-mr-def{

}

.tag_bottom_mob{
    text-align: center !important;
}
.blob{
    display: none;
}
.sec-fetr-rw {
    padding: 0px 20px;
    }
}



.menue-mob {
    background: pink;
    height: 100vh;
    z-index: 10000;
    position: fixed;
    width: 100%;
display: none;
    }

    nav.had-of-menu-mob {
    height: 10vh;
    background: white;
  }

  .btn-con-of-mob-mn {
    padding: 20px;
    height: 30vh;
    background: white;

  }

  ul.ul-con-of-mob-mn {
    height: 60vh;
    overflow: scroll;
    background: white;
    padding: 20px;
    margin: 0px;

  }

  .btn-con-of-mob-mn {
    padding: 20px;
    height: 30vh;
    background: white;

  }
  li.li-of-mob-mn-con {
    padding: 20px 0px;
    text-align: center;
    font-weight: 600;
    list-style: none;
  }

</style>
<nav class="c-nav c-nav--primary c-nav--alternate" role="navigation" aria-label="Primary navigation"><div class="c-nav__row o-nav--primary o-content-container"><div class="c-slacklogo" style='width:250px;'>
<img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="40">

    
</div><nav class="c-nav__list"><ul class="c-nav-level--1">

<li class="c-nav--primary__listitem font-fam-rob" ><a href="https://slack.com/intl/en-in/enterprise" >Why Sycista?</a></li>

<li class="c-nav--primary__listitem font-fam-rob" ><a href="https://slack.com/intl/en-in/enterprise" >Resources</a></li>

<li class="c-nav--primary__listitem font-fam-rob"><a href="https://slack.com/intl/en-in/enterprise" >Feature</a></li>


<li class="c-nav--primary__listitem font-fam-rob"><a href="https://slack.com/intl/en-in/pricing" >Pricing</a></li>


</ul>





<div class="c-nav--signed-out"><a  href="https://account.sycista.com/account/login/" >Sign in</a><a  href="https://account.sycista.com/account/signup/" class="c-button v--left v--primary" >Get started</a></div>



</nav>


<button aria-label="Menu" class="nav_menu_btn c-nav__icon v--menu u-border-radius--none" id='btn-mob-mn-trg'><svg xmlns="http://www.w3.org/2000/svg" width="24" height="17" viewBox="0 0 24 17" aria-label="" class="svg-replaced" shape-rendering="geometricPrecision"><path d="M0 0h24v3H0zm0 7h24v3H0zm0 7h24v3H0z" fill-rule="evenodd"></path></svg></button>


</div>





</nav>






<div class="menue-mob" id='mn-of-dv-mob-dt'>

    <nav class="had-of-menu-mob">
    
        <div class="c-nav__row o-nav--primary o-content-container"><div class="c-slacklogo" style="width:250px;">
<img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="40">

    
</div>


<button aria-label="Menu" class="nav_menu_btn c-nav__icon v--menu u-border-radius--none" id='mn-mob-cls'><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6.2253 4.81108C5.83477 4.42056 5.20161 4.42056 4.81108 4.81108C4.42056 5.20161 4.42056 5.83477 4.81108 6.2253L10.5858 12L4.81114 17.7747C4.42062 18.1652 4.42062 18.7984 4.81114 19.1889C5.20167 19.5794 5.83483 19.5794 6.22535 19.1889L12 13.4142L17.7747 19.1889C18.1652 19.5794 18.7984 19.5794 19.1889 19.1889C19.5794 18.7984 19.5794 18.1652 19.1889 17.7747L13.4142 12L19.189 6.2253C19.5795 5.83477 19.5795 5.20161 19.189 4.81108C18.7985 4.42056 18.1653 4.42056 17.7748 4.81108L12 10.5858L6.2253 4.81108Z" fill="currentColor" /></svg></button>


</div>
    
    </nav>


<div class="menue-con-of-mob">


    
    <ul class="ul-con-of-mob-mn">
        <li class="li-of-mob-mn-con">Product</li>
        <li class="li-of-mob-mn-con">Resource</li>
        <li class="li-of-mob-mn-con">Documentation</li>
        <li class="li-of-mob-mn-con">Guide</li>
<li class="li-of-mob-mn-con">Company</li>
<li class="li-of-mob-mn-con">Pricing</li>
    </ul>
    
    

</div>

<div class="btn-con-of-mob-mn">

    
    


<a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary" style="
    background: white;
    color: #611f69;
    border: 2px solid;
">Sign In</a><a href="http://localhost/html/dash/main/account/signup/" class="c-button v--left v--primary">Browse feature</a>



</div>
    


</div>


<script type="text/javascript">


$(document).on('click','#btn-mob-mn-trg',function(){


$("#mn-of-dv-mob-dt").css('display','block');


})


$(document).on('click','#mn-mob-cls',function(){

$("#mn-of-dv-mob-dt").css('display','none');

})
</script>

