





<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>


<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@100;300;400;500;600;700&family=Roboto&display=swap" rel="stylesheet">

<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@700&display=swap" rel="stylesheet">


<link rel="stylesheet" type="text/css" href="http://localhost/html/dash/main/fa-fold/css/all.css">
</head>

<link rel="stylesheet" type="text/css" href="./css/main.css">

<style type="text/css">


body{
	font-family: 'IBM Plex Sans', sans-serif !important;
letter-spacing:0.2px;
}



a:hover{
    border: 0px;
    text-decoration: none;
}
.lgs-txt {
    font-size: 25px;
    padding-left: 10px;
    font-weight: 600;
}

span.spn-ln-lg {
    padding: 2px;
    font-weight: 100;
    font-size: 30px;
    }

    sub {
    font-weight: 500;
}

.c-slacklogo{
	width: 200px;
}

.c-nav--primary .c-nav__list .c-nav-level--1 .c-nav--primary__listitem{
	font-weight: 400;
}

.main-conetent{
	padding-top: 70px;
}

.tag_ln_mn{
    font-size: 50px;
    line-height: 1.3;
    margin: 0px;
    font-family: 'Lato', sans-serif;
    letter-spacing: -0.4px;
}


.font-fam-rob{

    font-family: 'Roboto', sans-serif;
}
.container{
	margin: 0px;
	width: 100%;
padding: 0px;
}

.row{
	margin: 0px;
}
.rw-mini-con{
	padding: 100px 80px;
}

.col-txt-of-rw{
	padding: 0px 40px;
}




    .c-button {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    background: 0 0;
    border: none;
    cursor: pointer;
    border-radius: 4px;
    text-align: center;
    font-family: Slack-Circular-Pro,"Helvetica Neue",Helvetica,"Segoe UI",Tahoma,Arial,sans-serif;
    font-weight: 700;
    line-height: 1.28571429;
    letter-spacing: .8px;
    font-size: .875rem;
    text-transform: uppercase;
    text-decoration: none;
    padding: 19px 40px 20px;
    display: block;
    width: 100%;
    transition: box-shadow 420ms cubic-bezier(.165,.84,.44,1),color 420ms cubic-bezier(.165,.84,.44,1),background 420ms cubic-bezier(.165,.84,.44,1);

}



   .c-button.v--primary {
    background-color: #611f69;
    color: #fff;
    fill: #fff;
}


@media screen and (min-width: 48rem){
.c-button {
    display: inline-block;
    white-space: nowrap;
    flex-basis: auto;
    width: auto;

    }

}

    @media screen and (min-width: 64rem){
.c-button {
    font-size: .875rem;

}
}
@media screen and (min-width: 25rem){
.c-button {
    font-size: calc(.875rem + (0 * (100vw - 400px)/ 624));

    }


}
.t-contains-reverse-links .t-default-link, .t-default-link, a {
    color: #1264a3;
    cursor: pointer;
    text-decoration: none;
    border-bottom: 1px solid #1264a3;
    word-break: break-word;
    }


.background-clr{

	background: #f6efe8;
}

.pad-top{
    padding-top: 10px;
}


.txt-para-dt{

line-height: 1.5;
    letter-spacing: 0.8px;
    margin-top: 0;
    max-width: 27rem;
    margin-left: 0;
    color: black;
    font-weight: 500;
    padding-top: 10px;

}

img#fr-1-img-dt {
    width: 600px;
    animation-delay: 5s;
    height: 400px;
    
}


.fet-data-con-main{
    margin: 40px 0px;
    padding: 0px 30px;
}

.sec-fetr-rw {
    padding: 0px 80px;

}

.fet-ico {
    font-size: 50px;
    padding-bottom: 20px;
    color: #1264a3;
    font-weight: bolder;

    }

    .font-sz-fet-txt{
        letter-spacing: 0px;
        font-size: 16px;
    }

    .fet-head a{
        font-weight: 600;
    }

    .med_font_sz_head{
font-size: 25px;
text-align: center;
padding-top: 60px;
    }

    .txt-alg-rght{
        text-align: right;
    }

    li.li-ele-fet-def {
    list-style: none;
    margin-bottom: 20px;
    font-weight: 500;
    color: black;
    font-family: 'IBM Plex Sans', sans-serif !important;

}

.fet-def-fully {
    padding-top: 40px;

    }

    .fa-check-circle {
    color: #611f69;
    padding-right: 20px;
}

.part-app-ico {
    width: 50px;
    padding: 10px;
    border-radius: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
}

.con-cent-alg{
    text-align: center;
}


.main-mac-scr {
    border-radius: 10px;
    background: white;
}

.head-mac-scr {
    padding: 10px;
    height: 35px;
    }
    .btn-mac-scr {
    height: 15px;
    width: 15px;
    border-radius: 50%;
    margin: 0px 5px;
    display: inline-block;
}
.btn-cls {
    background: #FF605C;
    }

    .btn-min {
    background: #FFBD44;
}
.btn-max {
    background: #00CA4E;
    }

.mac-scr-con-main{
    padding: 0px 30px;
}

.lst-foot-nav{
    color: #696969;
    font-size: .875rem;
    margin-bottom: 10px;
}

.lst-foot-nav:hover{
    cursor: pointer;
}

.hrf-foot-nav{
    color: #696969;
    border-bottom: none;
}

.hrf-foot-nav:hover{
    color: #1264a3;
    border-bottom: none;
    text-decoration: none;
}

.txt-tran-cap {
    text-transform: uppercase;
    font-size: .875rem;
    font-weight: 900;
    color: #454545;
}

.foot-plcy-pad{
    padding:20px 40px;
}

.ls-pol-bot:hover{
    cursor: pointer;
}


.ls-pol-bot {
    display: inline-block;
    margin-bottom: 0px !important;
    padding: 10px;
    font-size: .875rem;
    color: #454545;
    font-weight: 800;

    }

    .soc-med-ico_hld{
        text-align: right;
    }

    span.copy-txt {
    font-weight: 500;
    color: #797373;

}

.copy-cont {
    padding: 10px 60px;
    background: #ece9e9;
font-size: 13px;
    }

    li.li-fr-side-nav {
    list-style: none;
}
</style>

<body>

<?php

require("./php/header.php");


?>

<div class="main-conetent">

<div class="container">
  <div class="rw-mini-con row background-clr">
    <div class="col-sm-6 col-txt-of-rw">
      
      <h2 class='tag_ln_mn'>Your Assistance is Our Profit.</h2>
      <p class='txt-para-dt'>Using Sycista|<sub>mail</sub> sheduled and automate email with social media marketing facility.</p>

<div class='pad-top'>
<a href="https://slack.com/intl/en-in/get-started" class="c-button v--primary " >Try for free</a>
</div>

    </div>
    <div class="col-sm-6" >


<div class="main-mac-scr api-sld" id="send-api-sld" style="display: block;background: #2b092b;">
    <div class="head-mac-scr" style="
   
">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr" style="
    text-align: center;
    display: inline-flex;
    width: 100%;
">




<div class="side-shw-dsg">

    <ul style="
    margin-bottom: 0px;
    padding: 10px;
">
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
        
        
        <li class="li-fr-side-nav"><svg height="40" width="40">
  <circle cx="20" cy="20" r="20" stroke-width="3" fill="#3c1a3c"></circle>
    
</svg>  
 </li>
    
    </ul>
    
</div>



<div class="main-bod-con" style="
    padding: 0px;
    overflow: hidden;
">


    <img src="https://smejoinup.com/wp-content/uploads/2018/03/8-ds-of-email-marketing.gif" style="border-bottom-right-radius: 10px;">

</div>

</div>


</div>
      
    </div>
  </div>



<div class="sec-fetr-rw">



 <h2 class='tag_ln_mn med_font_sz_head'>Make Email Beautiful</h2>


<div class='main-con-of-fet'>


<div class='mk-btfl row'>


   

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-id-badge"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" data-clog-click="" data-clog-ui-element="link_document_sharing">Contact Managment</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Add contact from different way like CSV file, add one by one or from Cloud.</div>
   


</div>

    
<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-pager"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Template</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">To Builde responsive Email from Our library or edit/code in Sycista|<sub>editor</sub></div>
   


</div>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-images"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Studio</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">help in Manage Images for easily use in Post on Social handel or email template.</div>
   


</div>

</div>

</div>


<div class='mk-dt-pwfl row'>

    <h2 class='tag_ln_mn med_font_sz_head'>Make Data Powerful</h2>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-poll-h"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Survey</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">For a poll Your confusion and clerify about next step for success.</div>
   


</div>


<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-users"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Social Media</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Sheduled post in multiple social media account for build interactive community.</div>
   


</div>


<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-cog"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Automation</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Automate your sending interest Using API and send personalized email.</div>
   


</div>

</div>


<div class='mk-dt-pwfl row'>

    <h2 class='tag_ln_mn med_font_sz_head'>Build Automation For Personalized</h2>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-server"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >SMTP</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Attached Your SMTP server Or use Our server to send email direct to inbox.</div>
   


</div>


<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
   <i class="fad fa-draw-circle"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >API</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Use Api To send email on your requested time.you're able to send dynamic content with Template.</div>
   


</div>


<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico">
    <i class="fad fa-chart-pie"></i>
    </div>
    <div class="fet-head">
    <a href="https://slack.com/intl/en-in/document-sharing" >Analysis</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Analyze your click and open data in Social Post or Email campign for better ideas.</div>
   


</div>

</div>






</div>



<div class='thrd-rw rw-mini-con row' style='background:#f5f5f5;'>

<div class='col-sm-6'>

<img class='img-con-fet-mr-def' src='https://image.flaticon.com/icons/svg/3089/3089926.svg' width="300">

</div>


<div class='col-sm-6 '>


<h2 class='tag_ln_mn' style='font-size:30px;line-height:1.3;margin:0px;'>Segment Audiance using Campign History.</h2>

<p class='txt-para-dt'>Build list as like your preferance and send specific filtered contact.</p>


<div class='fet-def-fully'>

<ul>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Segment Your List In different Parameter.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Use campign history to segment.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Analyze List data.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Reduced cost of campign.</li>

</ul>


</div>


</div>

</div>




<div class='thrd-rw rw-mini-con row' style=''>


<div class='col-sm-6 '>


<h2 class='tag_ln_mn' style='font-size:30px;line-height:1.3;margin:0px;'>Build resonsive and dynamic Template.</h2>

<p class='txt-para-dt'>Sycista|<sub>editor</sub> For build responsive and dynamic template that is also used for send With API.</p>


<div class='fet-def-fully'>

<ul>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Email template library.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Responsive Email for any device.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Dynamic content added in template.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Use image That saved In your Cloud.</li>

</ul>


</div>


</div>


<div class='col-sm-6 con-cent-alg' >

<img class='img-con-fet-mr-def' src='https://res.cloudinary.com/heptera/image/upload/v1599111277/home_page/temp-main-logo_y7jdoe.svg'   width="300">

</div>



</div>




<div class="sec-fetr-rw">



 <h2 class='tag_ln_mn med_font_sz_head'>Build Better with Partner</h2>


<div class='main-con-of-fet'>


<div class='mk-btfl row'>


   

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592640812/google-contacts_ywkv2b.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" data-clog-click="" data-clog-ui-element="link_document_sharing">Google Contact</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Add contact that present in personal contact directly from Google Contact in list.</div>
   


</div>

    
<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592640972/iconfinder_38_939833_jgcojl.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" >DropBox</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Import Contact from File store in DropBox and saved image present in DropBox.</div>
   


</div>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592640737/google-drive_hxuzbw.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" >Google Drive<sup>BETA</sup></a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">For a import contact in list directly from drive CSV/XLS file.</div>
   


</div>




<div class="col-sm-4 fet-data-con-main" >
    <div class="fet-ico con-cent-alg">
    <img class="part-app-ico" src="https://res.cloudinary.com/heptera/image/upload/v1599626538/home_page/iconfinder_unsplash_4691440_snpozk.png">
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing">Unsplash</a>
    </div>
    <div class="txt-para-dt font-sz-fet-txt">Unsplash for import high quality image from Unsplash using Studio.</div>
   


</div>

</div>

















</div>









</div>





<div class="sec-fetr-rw con-cent-alg">



 <h2 class='tag_ln_mn med_font_sz_head'>Build Interactive Community</h2>

<div class="txt-para-dt font-sz-fet-txt con-cent-alg" style='margin:auto;'>For sheduled post from Sycista And realease in Multiple account at a time.</div>
   



<div class='main-con-of-fet'>


<div class='mk-btfl row'>


   

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592641066/facebook_2_lw3ko8.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" data-clog-click="" data-clog-ui-element="link_document_sharing">FaceBook</a>
    </div>
    
   


</div>

    
<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592641183/twitter_1_wnavck.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" >Twitter</a>
    </div>
    


</div>

<div class="col-sm-4 fet-data-con-main">
    <div class="fet-ico con-cent-alg">
    <img class='part-app-ico' src='https://res.cloudinary.com/heptera/image/upload/v1592641126/instagram-sketched_wza9vp.png'>
    </div>
    <div class="fet-head con-cent-alg">
    <a href="https://slack.com/intl/en-in/document-sharing" >Instagram</a>
    </div>
    


</div>

</div>

















</div>









</div>



<div class='thrd-rw rw-mini-con row' style='background:#f5f5f5;'>

<div class='col-sm-6 mac-scr-con-main'>

<div class="main-mac-scr">
    <div class="head-mac-scr">
    <div class="btn-cls btn-mac-scr"></div>
    <div class="btn-min btn-mac-scr"></div>
    <div class="btn-max btn-mac-scr"></div>

</div>

<div class="img-mac-scr">
<img src="https://res.cloudinary.com/heptera/image/upload/v1599150330/Screen_Shot_1942-06-12_at_9.54.39_PM_usphjv.png" style="
    width: 100%;
">

</div>


</div>

</div>


<div class='col-sm-6 '>


<h2 class='tag_ln_mn' style='font-size:30px;line-height:1.3;margin:0px;'>Sending API for Automation.</h2>

<p class='txt-para-dt'>Send email in inbox when you requested with your content.</p>


<div class='fet-def-fully'>

<ul>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Built for developer with eazy documentation.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Integrate easily with security.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Send email that you want.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>Also send email that template build in editor.</li>
<li class='li-ele-fet-def'><i class="fas fa-check-circle"></i>build dynamic template with editor.</li>

</ul>


</div>


</div>

</div>









<?php

require("./php/sign_up_footer.php");

?>











</div>


</div>

<?php require("./php/footer.php");?>


</body>
</html>



<script type="text/javascript">


img_arr=['fr-1','fr-2','fr-3'];
img_cnt=0;

$(document).ready(function(){


setInterval(function(){ 



if(img_cnt<img_arr.length-1){

img_cnt=img_cnt+1;


    }else{
        
        img_cnt=0;

    }
console.log(img_cnt);


    append_img_in_row(img_cnt); 

}, 3000);


});

function append_img_in_row(img_id){


$("#fr-1-img-dt").attr('src','./images/'+img_arr[img_id]+".png");

}

</script>